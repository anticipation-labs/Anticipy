15 fictional SQLite memories. Final extraction probe, seeded notes plus long transcript; no real users or provider credentials. Transcript follow-up/task evidence is in persona-lab-evidence.json.
