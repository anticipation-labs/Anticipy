# Anticipy v4 — Local Daemon + Thin Chrome Extension

## What's in this bundle

- `extension_v4/` — Chrome extension (load unpacked from chrome://extensions)
- `installer/install.sh` — macOS installer that drops the Python daemon at
  ~/.anticipy/ and registers it with Chrome's native-messaging system
- `native_host/` — the Python daemon source (copied into ~/.anticipy/ by
  the installer)
- `engine/` — the agent logic the daemon imports (planner, critic,
  verifier, embeddings, trajectory cache, memory). All editable on your
  Mac without ever reloading the extension.

## Install (macOS)

```bash
bash installer/install.sh
```

Then in Chrome:
1. Visit chrome://extensions
2. Enable Developer mode (top-right toggle)
3. Click Load unpacked
4. Pick `extension_v4/` from this folder

Extension ID should be: `npnpagopediecennpleihemoochikggb`

## Uninstall

```bash
bash installer/uninstall.sh
```

## Edit agent logic without reloading

All the LLM prompts, planner / critic / verifier / reflector code lives
in `~/.anticipy/engine/app/`. Edit anything, close the popup, open it
again. The daemon imports lazily on each `task_start`, so changes are
picked up on the next task — no Chrome reload needed.

## Logs

`tail -f ~/Library/Logs/Anticipy/agent.log`
