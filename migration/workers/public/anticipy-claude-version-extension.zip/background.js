// Anticipy extension service worker.
// Polls the Anticipy backend (the backend) for action jobs and executes them in
// the user's own browser using their live logged-in sessions — browser-only,
// no service APIs. Irreversible steps stop at a prefilled page for the user
// (or the phone app) to confirm.

import {
  PAGE_READ_TIMEOUT_MS, RUN_WALL_CEILING_MS, createBackgroundTab, modelFetch, readPageForRecovery,
  reconcileJudge, runAgentGoal, withTimeout,
} from "./agent_loop.js";
import {
  MAX_STEPS as READ_MAX_STEPS, leaseLapsed, runSupervisedRead,
} from "./supervised_read.js";
import { backendBase } from "./config.js";
import { backgroundContextFromParams } from "./source_context.js";
import { backendFetch as fetch } from "./backend_transport.js";
import {
  effectIntentAfter,
  heartbeatPatch,
  isWorkflowJob,
  markEffectUncertainPatch,
  parseJobParams,
  workflowPatch } from "./workflow_state.js";
import {
  reconcileUncertainEffect, reconciledMessage, reconciliationParams, recoveryFor,
} from "./reconcile.js";

// Keep an engine marker in the service-worker entry file itself. Updating an
// imported module alone can leave Chrome running a cached worker graph for an
// unpacked extension; changing this entry file forces a fresh registration,
// and the same marker is written into every job trace as runtime proof.
const ENGINE_BUILD = "0.18.3";

const BACKEND_LLM = "backend-proxy";
// Job traffic authenticates as THIS ONE AGENT and nothing more. An earlier
// build also attached the server's master `X-Anticipy-Token` here, for the
// single release that let an already-paired install add its per-agent
// credential. /agent/key has returned `service_token: ""` since, and the save
// erases the stored value, so that branch could only ever send an empty
// header — and a browser carrying the server's master credential at all is
// worth deleting on its own account.
async function writeHeaders(leaseToken = "") {
  const { agentId, agentToken } = await chrome.storage.local.get(
    ["agentId", "agentToken"]);
  const h = { "Content-Type": "application/json" };
  if (agentId) h["X-Anticipy-Agent-ID"] = agentId;
  if (agentToken) h["X-Anticipy-Agent-Token"] = agentToken;
  if (leaseToken) h["X-Anticipy-Lease"] = leaseToken;
  return h;
}

// Chrome only guarantees recurring extension alarms every 30 seconds. Values
// below that can appear to work in development and then disappear after a
// service-worker/browser restart. Keep both wake paths at the supported floor
// and re-assert them whenever this worker boots (see ensureWakeAlarms below).
const WAKE_PERIOD_MINUTES = 0.5;
const WAKE_ALARMS = ["anticipy-poll", "anticipy-heartbeat"];
const LEASE_MS = 2 * 60 * 1000;
// A real task takes minutes: a booking, a spreadsheet, anything spanning two
// sites. Two minutes declared live work abandoned and handed it to the next
// sweep while it was still going. The heartbeat is meant to prevent that, but
// it lives in an in-memory set that a service-worker restart empties.
const STALE_JOB_MS = 8 * 60 * 1000; // running w/ no heartbeat -> requeued
// Retrying is right. Retrying without end is not. A job that has been started
// three times and finished none of them will not finish on the fourth — it
// will just keep opening tabs and typing. On 2026-08-06 the same Priya email
// ran about six times this way, because nothing counted.
const MAX_ATTEMPTS = 3;

// WHAT COUNTS AS THIS BROWSER'S WORK — one definition, two callers.
//
// The claim poll and the stale sweep both have to name the same lanes, and
// they used to do it with two hand-written copies of the same clause. They
// drifted, and the way it presented was brutal: research runs in the WORKER
// on a 120s never-heartbeated lease, so two minutes into every research job
// the sweep saw an expired lease on a row it is FORBIDDEN to write, PATCHed
// it, got 403, and that throw escaped the poll cycle before claimJob ever
// ran. For the whole duration of any research job the browser lane claimed
// nothing at all — while the heartbeat kept the phone showing "Chrome ready".
//
// workflow_id!="" keeps unplanned rows out; lane!="research" keeps out work
// that belongs to the server (roadmap §6: read-only goals run in the worker,
// and the backend's research_lane hook refuses a browser claim anyway).
//
// Excluding lane "api" (2026-09-06) keeps out the API hand's rows: brain/hands.py puts
// an `api` verdict on lane "api", brain/worker.py run_api_jobs claims it and
// the Worker's /hands/api/run executes it. Until this clause the poll NAMED
// lane — so the server's leg-1 rewrite appended nothing — and excluded only
// research, and the server had no api claim rule: a browser that polled
// before the brain claimed the row and ran an api errand through the browser
// vocabulary. The FLOOR is the server (migration/workers/src/policy/
// research_lane.ts refuses a non-worker claim on lane api whatever this
// filter says); this clause is the courtesy that stops a browser from even
// listing — and, through the sweep below, from trying to requeue — a row
// that was never its own. Proof: tests/test_api_lane_is_not_browser_work.mjs.
// Phone calendar work carries a workflow too. Listing ten such rows filled
// the entire claim page: the server correctly refused every claim, while the
// browser job behind them never got a turn. Supervised reads have a separate
// executor and must stay excluded even if a row happens to carry a workflow.
const BROWSER_LANE = 'workflow_id!="" && lane!="research" && lane!="api" && lane!="device_calendar" && lane!="supervised_read"';
const ownerLaneFilter = (status, ownerRef) =>
  `status="${status}" && owner_ref="${ownerRef}" && ${BROWSER_LANE}`;

// A SUPERVISED READ IS ITS OWN LANE, and it is invisible to the poll above on
// purpose — twice over. It carries no `workflow_id` (there is no plan to
// approve: the person is standing there watching), and
// `migration/workers/src/policy/research_lane.ts` now appends `lane != "supervised_read"`
// to any queued poll that does not NAME the lane. That second guard exists
// because an old extension in the wild would otherwise claim a read and run it
// through `runAgentGoal` with the full action vocabulary — clicking and typing
// inside somebody's mailbox, with no narration and nobody watching. So this
// filter names the lane explicitly, exactly as `noteResearchWaiting` does.
const supervisedReadFilter = (ownerRef) =>
  `status="queued" && owner_ref="${ownerRef}" && lane="supervised_read"`;

// The public setup page becomes live only on the exact backend this install is
// configured to use. Checking the complete origin + path here means a random
// page cannot ask the bridge for a pairing code merely because the extension
// already has broad browser permissions for its actual work.
async function isHostedSetupPage(value) {
  try {
    const root = `${await backendBase()}/`;
    const expected = new URL("setup.html", root);
    const candidate = new URL(value);
    return candidate.origin === expected.origin
      && candidate.pathname === expected.pathname;
  } catch (_) {
    return false;
  }
}

async function installHostedSetupBridge(tabId, url) {
  if (tabId == null || !(await isHostedSetupPage(url))) return false;
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["setup_bridge.js"],
    });
    return true;
  } catch (_) {
    return false;
  }
}

// ---------------------------------------------------------------- pairing
// Each install registers itself once with a 6-digit pair code. The phone app
// claims the code and writes `owner`; from then on this agent only takes
// that owner's jobs and reports a heartbeat the app turns into "last seen Ns".

let identityGeneration = 0;
let identityWrites = Promise.resolve();
const nonemptyIdentity = value => typeof value === "string" && value.trim().length > 0;

// Identity and its owner mirrors are one storage mutation. A retired identity
// must never lend its paired bit/profile to the new unpaired credential. Keep
// currentJob/handBacks: pairing recovery is not deletion of the owner's work.
function unpairedIdentity(agentId) {
  return { agentId, agentToken: "", recordId: "", pairCode: "", agentCredentialInstalled: false,
    owner: "", ownerRef: "", paired: false, ownerProfile: null,
    openrouterKey: "", agentModel: "", visionModel: "", serviceToken: "", keyFetchedAt: 0 };
}

function writeIdentity(generation, values) {
  const next = identityWrites.then(async () => {
    if (generation !== identityGeneration) return false;
    await chrome.storage.local.set(values);
    return generation === identityGeneration;
  });
  identityWrites = next.catch(() => {});
  return next;
}

const ownerScope = (ownerRef, generation = identityGeneration) => ({ ownerRef, generation });
// Run `fn` behind every identity write already queued, and queue it in turn.
function onIdentityQueue(fn) {
  const next = identityWrites.then(fn);
  identityWrites = next.catch(() => {});
  return next;
}
// THE SCOPE IS READ BEHIND THE QUEUE. freshIdentity() bumps the generation
// synchronously and queues its unpaired write; a reader that sampled the new
// generation and then read storage in that window saw the RETIRED owner under
// the NEW generation, and every fence downstream accepted it (review
// 2026-09-14, finding "readers sample identityGeneration outside the queue").
async function currentOwnerScope() {
  await identityWrites.catch(() => {});
  const generation = identityGeneration;
  const { ownerRef } = await chrome.storage.local.get(["ownerRef"]);
  return ownerScope(ownerRef, generation);
}
async function scopeIsCurrent(scope) {
  if (!scope || !nonemptyIdentity(scope.ownerRef) || scope.generation !== identityGeneration) return false;
  const { ownerRef } = await chrome.storage.local.get(["ownerRef"]);
  return scope.generation === identityGeneration && ownerRef === scope.ownerRef;
}
// Serialize derived owner state with identity replacement. Writers carry the
// owner captured before their asynchronous work; they never adopt whoever
// happens to be paired when a delayed response finally arrives.
function writeOwnerState(scope, build) {
  const next = identityWrites.then(async () => {
    if (!scope || !nonemptyIdentity(scope.ownerRef) || scope.generation !== identityGeneration) return false;
    const state = await chrome.storage.local.get(["ownerRef", "currentJob", "handBacks"]);
    if (scope.generation !== identityGeneration || state.ownerRef !== scope.ownerRef) return false;
    const values = build(state);
    if (!values) return false;
    await chrome.storage.local.set(values);
    return scope.generation === identityGeneration;
  });
  identityWrites = next.catch(() => {});
  return next;
}

function presentOwnerNotification(scope, id, notification) {
  // Chrome can present an already-submitted notification after its Promise
  // settles elsewhere. Identity retirement waits on this same queue, then
  // clears the prior notifications before exposing a replacement pair code.
  const next = identityWrites.then(async () => {
    if (!(await scopeIsCurrent(scope))) return false;
    await chrome.notifications.create(id, notification);
    return true;
  });
  identityWrites = next.catch(() => {});
  return next;
}

async function freshIdentity(agentId = crypto.randomUUID()) {
  const generation = ++identityGeneration;
  if (!(await writeIdentity(generation, unpairedIdentity(agentId)))) return null;
  // Stored receipts stay in place, but notifications from the retired owner
  // must not remain visible after the link has been dropped.
  const { handBacks = {} } = await chrome.storage.local.get(["handBacks"]);
  for (const key of Object.keys(handBacks)) {
    // false means already absent; a thrown API error means removal is
    // unconfirmed, so leave registration unavailable until a safe retry.
    await chrome.notifications.clear(`${HANDBACK_NOTIF}${key}`);
  }
  await refreshBadge();
  return generation === identityGeneration ? { generation, agentId } : null;
}

async function ensureRegisteredOnce() {
  let generation = identityGeneration;
  let { agentId, agentToken, recordId } =
    await chrome.storage.local.get(
      ["agentId", "agentToken", "recordId"]);
  if (generation !== identityGeneration) return null;
  if (nonemptyIdentity(recordId) && nonemptyIdentity(agentId) && nonemptyIdentity(agentToken)) {
    // The credential, not an obsolete local installation marker, is the
    // authority. A transient failed heartbeat never rotates this identity.
    return { agentId, agentToken, recordId, generation };
  }
  if (recordId) {
    // This shape cannot authenticate. The service-only upgrade endpoint is
    // deliberately unavailable to browsers; requesting it loops forever.
    // Recover only as a NEW UNPAIRED install, requiring the phone to claim it.
    const replacement = await freshIdentity();
    if (!replacement) return null;
    ({ agentId, generation } = replacement);
  } else {
    agentId = nonemptyIdentity(agentId) ? agentId : crypto.randomUUID();
    const replacement = await freshIdentity(agentId);
    if (!replacement) return null;
    generation = replacement.generation;
  }
  const post = async (id) => fetch(`${await backendBase()}/agent/register`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      agent_id: id,
      // The extension version rides along in this existing field so nobody has
      // to guess which build is actually installed. An unpacked extension does
      // not auto-update, so "did you reload it?" has been unanswerable — and it
      // is the single most common cause of the browser arm being dead.
      browser: `${navigator.userAgent.match(/Chrome\/[\d.]+/)?.[0] || "Chrome"} ext/${chrome.runtime.getManifest().version}`,
      last_seen: new Date().toISOString(),
    }),
  });
  let r = await post(agentId);
  // 409 means the server already has a row for this agent_id while we hold no
  // recordId — the worker was torn down (or the reply lost) in the gap between
  // saving agentId above and saving the registration result below. Re-POSTing
  // the same id 409s forever, and a null return here is total death: heartbeat
  // stops at !reg, claimJob has no ownerRef, ensureLLMKey has no token. Worse,
  // the setup page then says "Connected to Anticipy" while
  // showing ······ and promising a code that can never arrive, and the one
  // recovery button is hidden because it needs a pair code we never got. A
  // fresh identity is the way out: the orphaned row was never paired to anyone.
  if (r.status === 409) {
    console.warn("Anticipy: this browser's id was already registered without a local record — registering a fresh one");
    if (generation !== identityGeneration) return null;
    const replacement = await freshIdentity();
    if (!replacement) return null;
    ({ agentId, generation } = replacement);
    r = await post(agentId);
  }
  if (!r.ok) return null;
  const rec = await r.json();
  agentToken = rec.agent_token || "";
  const pairCode = rec.pair_code || "";
  if (!nonemptyIdentity(rec.id) || !nonemptyIdentity(agentToken) || !nonemptyIdentity(pairCode)) return null;
  if (!(await writeIdentity(generation, {
    agentId, agentToken, recordId: rec.id, pairCode, agentCredentialInstalled: true,
  }))) return null;
  return { agentId, agentToken, recordId: rec.id, generation };
}

// First install wakes this worker through more than one path: onInstalled and
// the immediate poll both need an identity. Without a single-flight guard they
// can register the same fresh browser twice and race while replacing its local
// record/token. Every caller shares one attempt and a later alarm may retry
// cleanly after that attempt has settled.
let registrationInFlight = null;
export async function ensureRegistered() {
  if (registrationInFlight) return registrationInFlight;
  registrationInFlight = ensureRegisteredOnce();
  try {
    return await registrationInFlight;
  } finally {
    registrationInFlight = null;
  }
}

// A credential the server has positively rejected cannot refresh itself: the
// refresh request carries the same rejected pair.  After repeated, explicit
// `agent credential is not recognized` replies, retire the local identity and
// mint a fresh unpaired one.  Clearing the owner link is essential — carrying
// an old ownerRef beside a new unpaired credential would make the popup claim
// it is linked while every scoped read is forbidden.
//
// This is intentionally exported for the offline recovery harness.  It is
// called automatically only after three matching server verdicts, or by the
// owner's explicit New code action; never for a generic 403 or an outage.
export async function recoverRejectedAgentCredential() {
  const previous = registrationInFlight;
  if (!(await freshIdentity())) return null;
  // A registration reply already in flight belongs to the retired generation.
  // Wait for its fenced settlement before requesting the replacement code.
  if (previous) await previous.catch(() => null);
  return ensureRegistered();
}

async function explicitlyUnrecognizedCredential(response) {
  if (!response || response.status !== 403) return false;
  try {
    const body = await response.clone().json();
    return String(body?.error || "") === "agent credential is not recognized";
  } catch (_) {
    return false;
  }
}

// Jobs this worker is actively running — their claims get refreshed on every
// heartbeat so the stale-requeue sweep never eats a live job.
const activeJobs = new Map();
const claimedOwnerScopes = new WeakMap();

// Two writers touch one job at once: the heartbeat alarm renews the lease while
// the run's own trace writer saves the evidence journal, and BOTH re-serialize
// the whole params blob. Interleaved, the heartbeat's older snapshot lands last
// and the row silently reverts to the previous journal — so a worker reclaimed
// in that window resumes having forgotten the last clinics it visited and goes
// back to re-open them. Nothing upstream can catch it: every lease and attempt
// field in that write is perfectly consistent.
//
// One chain per job, and the patch is BUILT INSIDE the chain, so each write is
// computed from what the previous one actually committed.
const jobWriteChains = new Map();
export function withJobWrite(id, build) {
  // The stored tail is always already-caught, so one failed write can never
  // strand every later write for that job.
  const prior = jobWriteChains.get(id) || Promise.resolve();
  const next = prior.then(build);
  jobWriteChains.set(id, next.catch(() => {}));
  return next;
}

// ------------------------------------------------------------- LLM key
// Consumers never paste API keys: once paired, the agent fetches its key from
// the backend. A manually saved key (popup) still wins, so dev overrides work.
async function ensureLLMKey(force = false) {
  const generation = identityGeneration;
  const { openrouterKey, agentModel, serviceToken, keyFetchedAt, agentId } =
    await chrome.storage.local.get(["openrouterKey", "agentModel", "serviceToken", "keyFetchedAt", "agentId"]);
  if (generation !== identityGeneration) return null;
  // Refresh when ANY piece is missing or the bundle is stale — not just the
  // key. `serviceToken !== undefined` is not about sending that token any more
  // (writeHeaders no longer does); it is the marker that says this install has
  // been through the CURRENT /agent/key at least once. An install that cached
  // only a key from an older build would otherwise look complete forever and
  // never pick up the model or the owner profile that arrive with it.
  const complete = openrouterKey === BACKEND_LLM
    && agentModel !== undefined && serviceToken !== undefined;
  const fresh = Date.now() - (keyFetchedAt || 0) < 6 * 3600 * 1000;
  if (!force && complete && fresh) return openrouterKey;
  if (!agentId) return complete ? openrouterKey : null;
  try {
    const r = await fetch(`${await backendBase()}/agent/key?agent_id=${encodeURIComponent(agentId)}`,
      { headers: await writeHeaders() });
    // A refresh that fails must never LOSE a key we already hold — a stale
    // bundle plus one backend hiccup would otherwise fail every job with
    // "no LLM key" while a perfectly good key sits in storage.
    if (!r.ok) return generation === identityGeneration && complete ? openrouterKey : null;
    const { llm_proxy, model, vision_model, service_token, owner, owner_ref } = await r.json();
    if (llm_proxy) {
      if (!(await writeIdentity(generation, {
        // An opaque routing marker, not a vendor credential. This overwrites
        // and removes any long-lived key cached by an older build.
        openrouterKey: BACKEND_LLM,
        agentModel: model || "",
        visionModel: vision_model || "",
        // The server no longer returns its master credential, and nothing in
        // this worker would send it if it did. Writing the empty value is how
        // an upgraded install ERASES the token an older build cached.
        serviceToken: service_token || "",
        ownerProfile: owner || null,
        ownerRef: owner_ref || "",
        keyFetchedAt: Date.now(),
      }))) return null;
      return BACKEND_LLM;
    }
  } catch (_) { /* backend unreachable; keep whatever we already had */ }
  return generation === identityGeneration && complete ? openrouterKey : null;
}

async function heartbeat() {
  const reg = await ensureRegistered();
  if (!reg) return null;
  // THE BEAT FIRST, THE RENEWALS AFTER. last_seen is the phone's whole idea
  // of "Chrome ready", and it used to be stamped only after every active
  // job's lease renewal had been awaited — each one chained behind in-flight
  // step writes and carrying the 20 s request deadline. One 15 s renewal was
  // measured to stretch the stamp gap from 30 s to 45 s, so a running errand
  // showed "Chrome asleep" on the phone with Chrome open and working. The
  // stamp is a fact about this worker being alive; it does not wait on the
  // job rows. The renewals still run, unconditionally, below.
  const rec = await stampLastSeen(reg);
  for (const [id, active] of activeJobs) {
    // A run that outlives the cycle ceiling is hung, and renewing its lease
    // is how a hung run becomes IMMORTAL: the stale-job sweep only recovers
    // work whose lease has expired, so a zombie kept beating would hold its
    // job forever. Stop beating for it and let the sweep hand it back.
    if (active.startedAt
        && Date.now() - active.startedAt > POLL_CYCLE_CEILING_MS) {
      console.warn(`Anticipy: job ${id} has run ${Math.round(
        (Date.now() - active.startedAt) / 1000)}s — dropping its lease so it can be recovered`);
      activeJobs.delete(id);
      continue;
    }
    try {
      active.job = await withJobWrite(id, () => {
        const until = new Date(Date.now() + LEASE_MS);
        const patch = isWorkflowJob(active.job)
          ? heartbeatPatch(active.job, { leaseToken: active.leaseToken, leaseUntil: until })
          : { claimed_at: new Date().toISOString() };
        return updateJob(id, patch, active.leaseToken);
      });
    } catch (e) {
      console.warn(`Anticipy: could not renew lease for ${id}: ${String(e).slice(0, 160)}`);
    }
  }
  return rec;
}

// The agents-row PATCH on its own: this worker's build and the moment it was
// alive. Null when the row could not be written; the storage mirror of
// owner/pairing is refreshed from what the row answered.
async function stampLastSeen(reg) {
  if (reg.generation !== identityGeneration) return null;
  const r = await fetch(`${await backendBase()}/api/collections/agents/records/${reg.recordId}`, {
    method: "PATCH",
    headers: await writeHeaders(),
    body: JSON.stringify({
      // Re-stamped on every beat, not just at registration: an agent that
      // registered long ago would otherwise report its old build forever,
      // and "which build is he actually running?" is the question this
      // field exists to answer.
      browser: `${navigator.userAgent.match(/Chrome\/[\d.]+/)?.[0] || "Chrome"} ext/${chrome.runtime.getManifest().version}`,
      last_seen: new Date().toISOString(),
    }),
  });
  if (!r.ok) return null;
  const rec = await r.json();
  // An UNPAIRED row has no owner whatever its owner_ref column still holds: an
  // older app, or a release made while signed out, clears `paired` without
  // clearing `owner_ref` (AnticipyBackend.swift:703-704 clears it only with an
  // account id). Keying on owner_ref alone kept the released owner's profile,
  // key, notifications and badge — and the popup's "Linked" — on the browser
  // (real-Chrome pass 3, 2026-09-14, "phone-repair").
  const nextOwner = rec.paired ? String(rec.owner_ref || "") : "";
  const { ownerRef: heldOwner } = await chrome.storage.local.get(["ownerRef"]);
  if (reg.generation !== identityGeneration) return null;
  if (nextOwner !== String(heldOwner || "")) {
    // THE PHONE CHANGED WHO THIS BROWSER BELONGS TO — released from the app, or
    // claimed by another owner with the code this install still holds. No New
    // code was pressed, so until 2026-09-14 nothing here noticed: the previous
    // owner's profile, model key, hand-back notifications and badge count all
    // survived into the next owner's pairing, and a delayed heartbeat or key
    // reply could even roll the owner back (review findings, phone-driven
    // owner change). The credential stays — it is this browser's — but the
    // generation moves so every in-flight writer of the old owner is fenced,
    // and everything the old owner was shown is taken down.
    const generation = ++identityGeneration;
    if (!(await writeIdentity(generation, {
      owner: rec.owner || "", ownerRef: nextOwner, paired: !!rec.paired,
      ownerProfile: null, openrouterKey: "", agentModel: "", visionModel: "", serviceToken: "", keyFetchedAt: 0,
    }))) return null;
    await retireOwnerPresentation();
    if (rec.paired && nextOwner) ensureLLMKey(true);
    return rec;
  }
  if (!(await writeIdentity(reg.generation, {
    owner: rec.owner || "",
    ownerRef: nextOwner,
    paired: !!rec.paired,
  }))) return null;
  // The moment pairing lands, pull the LLM key so the first job never
  // fails on a missing key.
  if (rec.paired) ensureLLMKey();
  return rec;
}

// If a previous worker died mid-job, its `running` jobs go stale; requeue them
// so no task is ever silently lost to a crash or a closed Chrome.
async function requeueStaleJobs() {
  // Owner-scoped: an unrelated install (a second Chrome profile, someone
  // else entirely) must never rewrite this owner's job rows.
  const { ownerRef } = await chrome.storage.local.get(["ownerRef"]);
  if (!ownerRef) return;
  const filter = encodeURIComponent(ownerLaneFilter("running", ownerRef));
  const r = await fetch(`${await backendBase()}/api/collections/jobs/records?filter=${filter}&perPage=20&sort=claimed_at`,
    { headers: await writeHeaders() });
  if (!r.ok) return;
  const { items } = await r.json();
  const now = Date.now();
  for (const j of items || []) {
   // One poisoned row must never cost the other nineteen their recovery.
   // A single refused PATCH used to throw straight out of this loop.
   try {
    if (activeJobs.has(j.id)) continue; // this worker is running it right now
    const expires = j.lease_until ? Date.parse(j.lease_until) : 0;
    const claimed = j.claimed_at ? Date.parse(j.claimed_at) : Date.parse(j.updated);
    if (expires ? now <= expires : now - claimed <= STALE_JOB_MS) continue;
    const tries = Number(j.attempts) || 0;
    if (isWorkflowJob(j) && j.effect_uncertain) {
      // WHAT WAS HERE UNTIL 2026-09-05, Audit #90: the constant sentence.
      // This site, the failed-with-uncertain branch and the catch in
      // runJobInner each wrote "I may have already sent that before I lost
      // the page — I could not confirm either way" (uncertainEffectMessage)
      // and nothing looked. The phone then turned the owner's Try again into
      // a constant reconciliation — conclusion not_applied, evidence "owner
      // explicitly checked the destination before retry" — which is exactly
      // what the DB guard's retry leg checks, so a crash plus a tap re-sent
      // the submission. Measured shape: a worker reclaimed mid-booking, the
      // Set the at-most-once gate keys on created empty, the same digest
      // dispatched again. Now the surviving tab is read once (the intent's
      // tab, this session only, on the intent's host only) and ONE model
      // question yields a four-state verdict written beside the intent. The
      // row still parks: the tap stays his, and it is still the only thing
      // that can release this row.
      await updateJob(j.id, recoveryFor(j, await recoverUncertainEffect(j)), j.lease_token);
      continue;
    }
    if (tries >= MAX_ATTEMPTS) {
      // Say so once, plainly, and stop. Leaving it queued would mean the next
      // sweep picks it up again and we are back where we started.
      const result = `I tried this ${tries} times and could not get it done. I have stopped rather than keep going.`;
      const patch = isWorkflowJob(j)
        ? { ...workflowPatch(j, "failed", { reason: result }), result }
        : { status: "failed", claimed_by: "", claimed_at: null, result };
      await updateJob(j.id, patch, j.lease_token);
      continue;
    }
    const patch = isWorkflowJob(j)
      ? workflowPatch(j, "queued", {
          reason: "executor lease expired before a confirmed external effect",
          effectUncertain: false,
        })
      : { status: "queued", claimed_by: "", claimed_at: null };
    await updateJob(j.id, patch, j.lease_token);
   } catch (e) {
     console.warn(`Anticipy: could not recover stale job ${j.id}: ${String(e).slice(0, 160)}`);
   }
  }
}

// ----------------------------------------------- saying why nothing happened
// claimJob returns null on six different refusals, and from the outside every
// one of them looks the same: nothing happens. Five of them said nothing at
// all, or said it to the service-worker console — which is not a place a
// person goes. So each refusal now leaves evidence somewhere findable: on the
// job row when the row can be written, and otherwise in the popup's mirror.
//
// The mirror has ONE slot, so a diagnosis may never displace a live run's
// line, and it deliberately carries NO job id: an id is what the popup's
// Stop/Again buttons key off, and what reconcileCurrentJob needs before it
// will touch the mirror at all.
async function noteBlocked(status, doing, why, scope) {
  if (activeJobs.size) return;
  await setCurrentJob({ id: "", status, doing, result: why, blocked: true }, scope, true);
}

// A diagnosis that outlives its problem is one more lie on the surface, and
// this one would otherwise sit there until the next job ran.
async function clearBlocked(scope) {
  try {
    await writeOwnerState(scope, ({ currentJob }) => currentJob?.ownerRef === scope.ownerRef
      && currentJob.blocked && !currentJob.id ? { currentJob: {} } : null);
  } catch (e) { /* best effort */ }
}

// THE 30-SECOND FLOOR, SAID OUT LOUD. chrome.alarms will not repeat faster
// than every half minute and there is no push channel, so a job can genuinely
// sit for ~30s before Chrome starts. The popup showed that as "Picking this
// up: <errand>" with nothing under it, which reads as a stall — and a stall is
// what makes people reload the extension mid-handshake. Say the wait instead.
const QUEUED_SOON = "It's in the queue. I check for new work every half minute, so I'll start "
  + "within about 30 seconds — and opening this popup nudges me straight away.";

// Rows this worker has already explained, and when. A diagnosis rewritten
// every 30 seconds is noise, but suppressing it FOREVER is worse: the popup
// has one slot, so any real work that arrives behind an unrunnable row
// overwrites the explanation, and without a re-say window the only account of
// a permanently stuck job would be gone for the life of the browser.
const explained = new Map();
const RESAY_MS = 10 * 60 * 1000;

// A job with no canonical plan cannot be run here: workflow_state is the only
// thing that authorises a step and there is nothing to read. Two shapes, two
// honest endings.
async function explainNoPlan(job, scope) {
  if (Date.now() - (explained.get(job.id) || 0) < RESAY_MS) return;
  explained.set(job.id, Date.now());
  console.warn(`Anticipy: refusing job ${job.id} without canonical workflow metadata`);
  const line = "This arrived without the plan Anticipy attaches to real work, so this browser cannot run it.";
  if (!job.workflow_id) {
    // A pre-workflow row is writable — nothing guards it. Ending it is kinder
    // than leaving it queued forever, where anyone reading the queue sees work
    // that looks about to happen and never will.
    try {
      const had = (job.result || "").trim();
      await updateJob(job.id, {
        status: "failed", claimed_by: "", claimed_at: null,
        result: `${had ? had + "\n\n" : ""}${line} Ask me for it again and I will queue it properly.`,
      });
      return;
    } catch (e) {
      console.warn(`Anticipy: could not annotate plan-less job ${job.id}: ${String(e).slice(0, 160)}`);
    }
  }
  // workflow_id is set but the embedded plan is missing or unparseable. EVERY
  // patch to such a row is refused by workflow_guard.pb.js ("canonical
  // workflow is missing from params"), including one that writes nothing but
  // `result` — that is the guard working as designed. The popup is the only
  // place left to say it, so say it there.
  await noteBlocked("needs_user", `I can't run one of the jobs in your queue (${job.id})`,
    `${line} Everything else still runs; that one needs to be called off from the app.`,
    ownerScope(job.owner_ref, scope.generation));
}

// A refused read is not "no work". One is a blip; several in a row is a queue
// nobody is reading, with a heartbeat still telling the phone all is well.
let pollFailures = 0;
let credentialRefusals = 0;

// Exported for the offline test harness: every refusal below has to be
// provable, and poll() is not something a test can steer.
export async function claimJob() {
  const generation = identityGeneration;
  // Owner-scoped: a paired agent takes its owner's jobs; an unpaired agent
  // takes nothing at all.
  const { ownerRef, agentId } = await chrome.storage.local.get(["ownerRef", "agentId"]);
  const scope = ownerScope(ownerRef, generation);
  if (generation !== identityGeneration) return null;
  // An UNPAIRED agent must not claim anything: it cannot fetch a key, so it
  // would claim the job and then fail it forever — a second Chrome profile
  // silently killing the owner's work.
  if (!ownerRef) {
    // A paired bit alone is not an owner. Setup and the popup show unlinked;
    // do not invent an ownerless task mirror to explain a pairing problem.
    return null;
  }
  // Same lanes as the sweep, from the same definition — see BROWSER_LANE.
  const cond = ownerLaneFilter("queued", ownerRef);
  // TEN ROWS, NOT ONE. This asked for a single row and gave up on it when it
  // turned out to be unclaimable — so ONE poisoned job at the head of the
  // queue (no plan attached, or three attempts already spent) froze the whole
  // browser lane for as long as it sat there, with nothing running and nothing
  // said anywhere. Read a few, run the first that can be run, and account for
  // the ones that cannot.
  const poll = async () => fetch(
    `${await backendBase()}/api/collections/jobs/records?filter=${encodeURIComponent(cond)}&perPage=10&sort=created`,
    { headers: await writeHeaders() }
  );
  let r = await poll();
  if (!(await scopeIsCurrent(scope))) return null;
  // A REFUSED read is not "no work". This returned null on any !ok, so once the
  // stored token went stale the browser arm went permanently, silently deaf:
  // the 10-second heartbeat kept working — PATCHing last_seen needs no token —
  // so the phone showed "Chrome ready" while every job poll was being turned
  // away. Omar watched a released booking sit in the queue with a live-looking
  // browser and nothing happening. Get a fresh key and try once more.
  if (r.status === 401 || r.status === 403) {
    console.warn("Anticipy: job poll refused - refreshing my key and retrying");
    await ensureLLMKey(true);
    if (!(await scopeIsCurrent(scope))) return null;
    r = await poll();
    if (!(await scopeIsCurrent(scope))) return null;
    if (!r.ok) {
      if (await explicitlyUnrecognizedCredential(r)) {
        credentialRefusals += 1;
      } else {
        credentialRefusals = 0;
      }
      if (credentialRefusals >= 3) {
        console.warn("Anticipy: the server rejected this retired browser identity three times — replacing it with a fresh pairing code");
        credentialRefusals = 0;
        const replacement = await recoverRejectedAgentCredential();
        await noteBlocked("needs_user", "This browser needs to be linked again",
          replacement
            ? "Its old private browser credential was retired by Anticipy. Open Setup, then enter the new pairing code in the iPhone app."
            : "Its old private browser credential was retired and a replacement could not be created. Open the extension Setup page and press New code.", scope);
        return null;
      }
      console.warn("Anticipy: still refused after refresh -", r.status,
                   "- reload this extension from the setup page if it persists");
      // This one never heals on its own: the credential this browser holds is
      // not one the backend will accept, and the heartbeat keeps saying
      // "Chrome ready" the entire time.
      await noteBlocked("needs_user", "I can't read your queue from this browser",
        `Anticipy refused this browser's credential (${r.status}). Reload the extension from the setup page; if that doesn't clear it, pair this browser again.`, scope);
      return null;
    }
  }
  credentialRefusals = 0;
  if (!r.ok) {
    pollFailures += 1;
    if (pollFailures >= 3) {
      await noteBlocked("needs_user", "I can't reach your queue right now",
        `Anticipy hasn't answered this browser for ${pollFailures} tries (last: ${r.status}). If you're online, check the backend address under Setup & advanced.`, scope);
    }
    return null;
  }
  pollFailures = 0;
  await clearBlocked(scope);
  const items = (await r.json()).items || [];
  const me = agentId || "unknown";
  for (const job of items) {
    if (!(await scopeIsCurrent(scope))) return null;
    if (activeJobs.has(job.id)) continue;
    if (!isWorkflowJob(job)) { await explainNoPlan(job, scope); continue; }
    // Nothing executes while Chrome is shut, so a job can sit for days.
    // Opening the laptop on Monday should NOT silently fire Friday's errand —
    // the world has moved on. Hand it back and let the owner say whether it
    // still stands.
    //
    // Measured from when it was last QUEUED, not from when the row was
    // created. `created` is immutable in the backend, so reading it meant a
    // task that had merely EXISTED for 12 hours was bounced — including one
    // the owner had just this second unblocked by answering. His Cactus
    // booking was created 21h before he supplied his details; every resume
    // would have been refused, forever, while she had already told him "I'll
    // finish the booking now". `updated` is refreshed by the requeue that sets
    // status back to "queued", so a fresh resume reads as fresh and a
    // genuinely abandoned errand does not.
    const STALE_HOURS = 12;
    const queuedAt = Date.parse(job.updated || job.created || "");
    if (queuedAt && Date.now() - queuedAt > STALE_HOURS * 3600 * 1000) {
      const hrs = Math.round((Date.now() - queuedAt) / 3600000);
      // Say only what is observable. The previous wording asserted "my browser
      // was closed" — written by the browser, while running, at the moment it
      // wrote it. And it OVERWROTE `result`, destroying the requirement text
      // ("I need your first name, last name, email…") that the brain matches
      // an answer against, so the task could never be resumed by answering
      // again.
      const had = (job.result || "").trim();
      try {
        await updateJob(job.id, {
          ...workflowPatch(job, "needs_user", {
            reason: `Still queued after ${hrs} hours without running. Does it still stand?`,
          }),
          result: (had ? had + "\n\n" : "") +
            `Still queued after ${hrs} hours without running. Does it still stand?`,
        });
      } catch (e) {
        console.warn(`Anticipy: could not park stale job ${job.id}: ${String(e).slice(0, 160)}`);
      }
      continue;
    }
    // Counted at the claim, which is the only place that means "started".
    // Counting on failure would miss the case that actually bit: a job that
    // never reaches an ending at all and is swept back to queued forever.
    const tries = (Number(job.attempts) || 0) + 1;
    if (tries > MAX_ATTEMPTS) {
      try {
        await updateJob(job.id, {
          ...workflowPatch(job, "cancelled", {
            reason: `stopped after ${tries - 1} attempts`,
          }),
          result: `I tried this ${tries - 1} times and could not get it done. I have stopped rather than keep going.`,
        });
      } catch (e) {
        console.warn(`Anticipy: could not close spent job ${job.id}: ${String(e).slice(0, 160)}`);
      }
      continue;
    }
    // Stamp the claim, then read it back: whoever's stamp survives owns the
    // job. This closes the race where concurrent poll() calls (a wake alarm,
    // the popup's anticipy-ping, and this worker booting can all overlap)
    // would each spawn an agent loop for the same job.
    //
    const leaseToken = crypto.randomUUID();
    let fresh;
    try {
      fresh = await updateJob(job.id, workflowPatch(job, "running", {
        actorId: me,
        leaseToken,
        leaseUntil: new Date(Date.now() + LEASE_MS),
        attempt: tries,
      }));
    } catch (e) {
      // A refused claim is somebody else's win or a guard rejection. Either
      // way the NEXT row may still be ours — one bad row must not cost the
      // rest of the queue its turn.
      console.warn(`Anticipy: could not claim ${job.id}: ${String(e).slice(0, 200)}`);
      continue;
    }
    if (fresh.claimed_by !== me || fresh.status !== "running" || fresh.lease_token !== leaseToken) continue;
    if (!(await scopeIsCurrent(scope))) return null;
    // Publish only a claim this browser owns. A guard refusal or another
    // browser winning the lease must not replace the last result with a
    // "picking this up" card for work this browser will never start. This is
    // still before the model call and tab creation in runJob.
    await setCurrentJob({ id: fresh.id, status: "queued",
                          doing: jobLine(fresh, parseJobParams(fresh)),
                          result: QUEUED_SOON, blocked: false }, ownerScope(fresh.owner_ref, generation), true);
    claimedOwnerScopes.set(fresh, ownerScope(fresh.owner_ref, generation));
    return fresh;
  }
  // Nothing here was runnable. Before going quiet, answer the question the
  // owner is actually asking when they open the popup.
  if (!items.length) await noteResearchWaiting(ownerRef, scope);
  return null;
}

// "Nothing is queued for this browser" and "something is queued somewhere
// else" look identical from in here, and the second one is not this browser's
// fault. A queued RESEARCH job is invisible to the poll above — the server
// hides that lane from browsers on purpose, because read-only work runs in the
// worker — so a stalled brain worker presents to the owner as a dead Chrome.
// One extra read, and only when this browser has nothing of its own to do.
async function noteResearchWaiting(ownerRef, scope) {
  try {
    // Naming `lane` is what keeps research_lane.pb.js from rewriting this
    // filter (it only appends its exclusion to a queued poll that does not
    // mention the lane), and naming owner_ref is what guard.pb.js requires of
    // any list an agent credential is allowed to read.
    const researchCond = `status="queued" && owner_ref="${ownerRef}" && lane="research"`;
    const r = await fetch(
      `${await backendBase()}/api/collections/jobs/records?filter=${encodeURIComponent(researchCond)}&perPage=1&sort=created`,
      { headers: await writeHeaders() });
    if (!r.ok) return;
    const job = ((await r.json()).items || [])[0];
    if (!job) { await clearBlocked(scope); return; }
    const mins = Math.round((Date.now() - Date.parse(job.updated || job.created || "")) / 60000);
    // The worker normally takes one of these within seconds, so anything
    // under a couple of minutes is not yet a symptom worth a line on screen.
    if (!(mins >= 2)) return;
    // A status the popup has no sentence for on purpose: it renders the line
    // below verbatim instead of forcing this into "I'm picking this up",
    // which is exactly what this browser is NOT going to do.
    await noteBlocked("waiting",
      `Waiting on Anticipy's own side, not on this browser: ${jobLine(job, parseJobParams(job))}`,
      `That one is a look-it-up job, so it runs on Anticipy's server rather than in your browser — and it has been waiting ${mins} minutes. Nothing here is broken.`,
      ownerScope(job.owner_ref, scope.generation));
  } catch (e) { /* a diagnosis must never break the poll */ }
}

// What the popup shows. The job row on the server stays the source of truth;
// this is a small local mirror so the machine the work is happening on can
// say what it is doing without a round trip. Best-effort by design — the
// mirror must never be able to break a run.
async function setCurrentJob(patch, scope, replace = false) {
  try {
    return await writeOwnerState(scope, ({ currentJob = {} }) => {
      const sameOwner = currentJob.ownerRef === scope.ownerRef;
      if (!replace && (!sameOwner || patch.id !== currentJob.id)) return null;
      const previous = sameOwner && (!Object.hasOwn(patch, "id") || patch.id === currentJob.id)
        ? currentJob : {};
      return { currentJob: { ...previous, ...patch, ownerRef: scope.ownerRef, at: Date.now() } };
    });
  } catch (e) { /* best effort */ }
  return false;
}

// ---------------------------------------------- never-foreground hand-back
// §9: nothing she does may steal focus, ever. When a run ends needing the
// owner — a login wall, a CAPTCHA, a prefilled page awaiting their OK — the
// tab stays in the background where it is. A badge on the extension icon and
// a notification are how the owner finds it; focus moves ONLY on their click.
// Exported for the offline test harness.
const HANDBACK_NOTIF = "anticipy-handback-";

// Everything the previous owner was SHOWN comes down when the owner changes:
// every hand-back notification (the records themselves stay, owner-tagged and
// hidden from anyone else), then the badge is recounted for the new owner.
async function retireOwnerPresentation() {
  try {
    const { handBacks = {} } = await chrome.storage.local.get(["handBacks"]);
    for (const key of Object.keys(handBacks)) {
      try { await chrome.notifications.clear(`${HANDBACK_NOTIF}${key}`); } catch (e) { /* gone */ }
    }
  } catch (e) { /* best effort */ }
  await refreshBadge();
}

// A record written before hand-backs carried an owner tag (0.18.2 and older)
// belongs to the owner this install held: an install had exactly one owner
// then. Adopted once, at boot, only while an owner is held — an untagged
// record on an unpaired install stays hidden (see openHandBack).
// WHY THERE IS NO LEGACY HAND-BACK ADOPTION HERE (2026-09-14).
//
// 0.18.2 wrote hand-back records with no owner tag, and the obvious kindness on
// upgrade is to stamp them with the owner this install currently holds: before
// 0.18.3 an install had one owner, so an untagged record must be theirs.
//
// That premise is false, and this very file is the proof. 0.18.2's heartbeat
// rewrote `ownerRef` IN PLACE when the phone reassigned the browser (see
// stampLastSeen below) and cleared neither `handBacks` nor the owner's key and
// profile -- which is the defect this release exists to fix. So an install that
// changed hands under 0.18.2 carries owner A's untagged record while holding
// owner B's identity, and adoption would hand A's parked page, and its URL, to
// B on B's first boot: exactly the cross-owner leak, arriving through the
// convenience meant to smooth the upgrade.
//
// Untagged records are therefore left untagged and stay invisible: refreshBadge
// counts only records whose ownerRef matches, the popup snapshot does the same,
// and tabs.onRemoved disposes of them when the tab closes. The cost is that a
// single-owner install upgrading from 0.18.2 loses one pending notification.
// That is the right side of the trade, and it is the whole of the cost.

async function refreshBadge() {
  try {
    const { handBacks = {}, ownerRef } = await chrome.storage.local.get(["handBacks", "ownerRef"]);
    const n = nonemptyIdentity(ownerRef)
      ? Object.values(handBacks).filter(item => item.ownerRef === ownerRef).length : 0;
    await chrome.action.setBadgeBackgroundColor({ color: "#c8a97e" });
    await chrome.action.setBadgeText({ text: n ? String(n) : "" });
  } catch (e) { /* best effort */ }
}

export async function surfaceHandBack(tabId, detail, kind, capturedScope = null) {
  const scope = capturedScope || await currentOwnerScope();
  try {
    let url = "";
    try { url = (await chrome.tabs.get(tabId)).url || ""; } catch (e) { /* gone already */ }
    if (!(await writeOwnerState(scope, ({ handBacks = {} }) => ({ handBacks: {
      ...handBacks, [String(tabId)]: { url, detail: String(detail || ""), kind: kind || "needs_user",
        ownerRef: scope.ownerRef, at: Date.now() },
    } })))) return;
    await refreshBadge();
    if (!(await scopeIsCurrent(scope))) return;
    let site = "the page";
    try { site = new URL(url).hostname.replace(/^www\./, "") || site; } catch (e) { /* no url yet */ }
    await presentOwnerNotification(scope, `${HANDBACK_NOTIF}${tabId}`, {
      type: "basic",
      iconUrl: chrome.runtime.getURL("icons/icon128.png"),
      title: "Anticipy",
      message: kind === "confirm"
        ? `Ready for your OK on ${site} — click to open.`
        : `I need you on ${site} — click to open.`,
      contextMessage: String(detail || "").replace(/\s+/g, " ").slice(0, 120),
      priority: 2,
      requireInteraction: true,
    });
    if (!(await scopeIsCurrent(scope))) await chrome.notifications.clear(`${HANDBACK_NOTIF}${tabId}`);
  } catch (e) {
    // A hand-back that can't notify still shows in the popup (badge/handBacks
    // may have landed) — never let the surface break the job result.
  }
}

export async function openHandBack(tabId, expectedOwnerRef = null) {
  const scope = await currentOwnerScope();
  const key = String(tabId);
  const { handBacks = {} } = await chrome.storage.local.get(["handBacks"]);
  const hb = handBacks[key];
  if (!hb || hb.ownerRef !== scope.ownerRef || (expectedOwnerRef !== null && expectedOwnerRef !== scope.ownerRef)
      || !(await scopeIsCurrent(scope))) return false;
  try {
    const t = await chrome.tabs.get(Number(key));
    if (!(await scopeIsCurrent(scope))) return false;
    try { await chrome.tabs.ungroup(t.id); } catch (e) { /* not grouped */ }
    if (!(await scopeIsCurrent(scope))) return false;
    // FOCUS-OK(owner-click): the owner clicked the notification or the popup
    // button — the one gesture that may bring a working tab forward.
    await chrome.tabs.update(t.id, { active: true });
    await chrome.windows.update(t.windowId, { focused: true });
  } catch (e) {
    // The tab is gone (swept, or Chrome restarted) — a click that opens
    // nothing reads as a broken promise, so reopen the page instead.
    if (hb && hb.url && await scopeIsCurrent(scope)) {
      // FOCUS-OK(owner-click): same owner gesture, fresh tab.
      try { await chrome.tabs.create({ url: hb.url, active: true }); } catch (e2) { /* give up quietly */ }
    }
  }
  if (hb) {
    await writeOwnerState(scope, ({ handBacks: current = {} }) => {
      if (current[key]?.ownerRef !== scope.ownerRef || current[key]?.at !== hb.at) return null;
      const kept = { ...current }; delete kept[key];
      return { handBacks: kept };
    });
  }
  await refreshBadge();
  try { await chrome.notifications.clear(`${HANDBACK_NOTIF}${key}`); } catch (e) { /* gone */ }
  return true;
}

chrome.notifications.onClicked.addListener((id) => {
  if (id.startsWith(HANDBACK_NOTIF)) openHandBack(id.slice(HANDBACK_NOTIF.length));
});

// A hand-back tab the owner closes by hand is answered — drop its badge.
chrome.tabs.onRemoved.addListener(async (tabId) => {
  // Whoever owned it: the entry is keyed by a tab that no longer exists, so
  // removing it can show nothing to anyone — and leaving it (as an unpaired
  // install did until 2026-09-14) resurfaced a ghost hand-back with a stale
  // badge the moment the phone paired again. On the identity queue, so it
  // cannot interleave with an owner write.
  const key = String(tabId);
  try {
    const removed = await onIdentityQueue(async () => {
      const { handBacks = {} } = await chrome.storage.local.get(["handBacks"]);
      if (!handBacks[key]) return false;
      const kept = { ...handBacks }; delete kept[key];
      await chrome.storage.local.set({ handBacks: kept });
      return true;
    });
    if (!removed) return;
    await refreshBadge();
    try { await chrome.notifications.clear(`${HANDBACK_NOTIF}${key}`); } catch (e) { /* gone */ }
  } catch (e) { /* best effort */ }
});

// One line a person would recognise as their own errand.
function jobLine(job, params) {
  const t = (params && (params.task || params.query || params.subject)) || job.goal || "a task";
  return String(t).replace(/\s+/g, " ").trim().slice(0, 140);
}

async function fetchJob(id) {
  const r = await fetch(`${await backendBase()}/api/collections/jobs/records/${id}`,
    { headers: await writeHeaders() });
  if (r.status === 404) throw new Error("job gone");
  if (!r.ok) throw new Error(`job read failed (${r.status})`);
  return r.json();
}

async function updateJob(id, fields, leaseToken = "") {
  const r = await fetch(`${await backendBase()}/api/collections/jobs/records/${id}`, {
    method: "PATCH",
    headers: await writeHeaders(leaseToken),
    body: JSON.stringify(fields),
  });
  // A silently-swallowed write meant a job deleted server-side ran to
  // completion while every status update vanished into the void.
  if (!r.ok) {
    if (r.status === 404) { activeJobs.delete(id); throw new Error("job gone"); }
    let detail = "";
    try {
      const error = await r.json();
      const validation = error?.data && typeof error.data === "object"
        ? Object.entries(error.data).map(([field, value]) =>
            `${field}: ${String(value?.message || value || "invalid")}`).join("; ")
        : "";
      detail = [error?.detail, error?.message, validation]
        .map((value) => String(value || "").trim()).filter(Boolean).join("; ");
    } catch (_) {}
    throw new Error(`job update failed (${r.status})${detail ? `: ${detail}` : ""}`);
  }
  return r.json();
}

/// Is this job still ours to run? The owner can cancel from the app or by
/// text while the loop is mid-flight; without this the run continued and
/// then RESURRECTED the cancelled job as done/failed.
// A REFUSED LIVENESS READ IS NOT REVOCATION UNTIL THE SERVER SAYS SO. The
// guard fails closed: a D1 hiccup inside recordOwner() answers a perfectly
// valid claimant 403 "agent is not allowed to access that record"
// (policy/guard.ts), and until 2026-09-14 one such read ended a live errand
// and told the owner "you called this off" (review finding). The poll's own
// rule (claimJob) acts only on an EXPLICIT "agent credential is not
// recognized" verdict; the liveness read now does the same, and a streak of
// bare refusals still ends the run — bounded, so a dead credential cannot
// keep a tab alive.
let livenessRefusals = 0;
const LIVENESS_REFUSAL_STOP = 3;
async function jobStillLive(id, leaseToken = "") {
  try {
    const r = await fetch(`${await backendBase()}/api/collections/jobs/records/${id}`,
      { headers: await writeHeaders() });
    if (r.status === 404) return false;
    if (r.status === 401 || r.status === 403) {
      if (await explicitlyUnrecognizedCredential(r)) return false;
      livenessRefusals += 1;
      return livenessRefusals < LIVENESS_REFUSAL_STOP;
    }
    if (!r.ok) return true;   // transient: don't abandon real work
    livenessRefusals = 0;
    const j = await r.json();
    if (isWorkflowJob(j)) {
      return j.workflow_state === "running" && j.lease_token === leaseToken;
    }
    return j.status === "running" || j.status === "queued";
  } catch (_) {
    return true;
  }
}

// ----------------------------------------------------- resuming a parked tab
// A parked run's tab IS its state: the site's session, the half-filled form,
// the code the site just sent. So the tab id is written onto the durable job
// row and a resume reattaches to it instead of starting the world over.
//
// But a Chrome tab id is unique only inside ONE browser session and is handed
// out again from the start after a restart. A job parked on Friday and
// answered on Monday would reattach to whatever tab now holds id 847 — the
// owner's banking dashboard, a document they left open — and drive
// chrome.debugger into it, clicking and typing a booking flow into a page that
// has nothing to do with the errand. chrome.storage.session is emptied exactly
// when the browser session ends, so it answers the only question that matters
// here: is that id still ours?
async function browserSessionId() {
  try {
    const store = chrome.storage.session;
    // An install too old for session storage cannot prove the id is still
    // ours, and an unprovable id is a stranger's tab.
    if (!store) return "";
    const { browserSession } = await store.get(["browserSession"]);
    if (browserSession) return browserSession;
    const fresh = crypto.randomUUID();
    await store.set({ browserSession: fresh });
    return fresh;
  } catch (_) { return ""; }
}

// The parked tab id, but only when this browser session is the one that parked
// it. Starting fresh costs a filled form; reattaching to the wrong tab types
// into the owner's own work.
export async function resumableTabId(params) {
  if (!params || params.resume_tab == null) return null;
  const session = await browserSessionId();
  if (!session || params.resume_session !== session) return null;
  return params.resume_tab;
}

// Did the OWNER stop this, or did we merely lose our claim on it? Only the row
// knows. A cancelled row is their decision; a row back in the queue (or claimed
// by another window) is ours to be quiet about.
async function ownerCancelled(id) {
  try {
    const j = await fetchJob(id);
    return isWorkflowJob(j) ? j.workflow_state === "cancelled" : j.status === "cancelled";
  } catch (_) {
    // Deleted, or unreadable right now. A row that is gone was called off.
    return true;
  }
}

// Server state -> the word the popup shows. "cancelled" reads as "stopped"
// because that is what the owner did and the popup has no other line for it.
const MIRROR_FOR_STATE = Object.freeze({
  draft: "awaiting_confirm",
  awaiting_approval: "awaiting_confirm",
  awaiting_confirm: "awaiting_confirm",
  queued: "queued",
  running: "running",
  needs_user: "needs_user",
  succeeded: "done",
  done: "done",
  failed: "failed",
  cancelled: "stopped",
});

// The popup's mirror is written when a run STARTS and never again if this
// worker dies mid-job. Quit Chrome during a booking and the mirror freezes at
// "running": the sweep requeues the row, a retry finishes it, and next morning
// the popup still says "Working on this: book Earls for 4" about work that
// ended yesterday — with a Stop button whose write the state machine refuses,
// because succeeded is terminal. refreshBadge exists precisely because a
// restarted browser comes up with derived state wrong; the mirror comes up
// STALE rather than blank, which is worse, and had no equivalent repair.
export async function reconcileCurrentJob() {
  const generation = identityGeneration;
  try {
    const { currentJob } = await chrome.storage.local.get(["currentJob"]);
    if (!currentJob || !currentJob.id) return;
    const scope = ownerScope(currentJob.ownerRef, generation);
    if (!(await scopeIsCurrent(scope))) return;
    if (activeJobs.has(currentJob.id)) return; // this worker is running it now
    let row;
    try {
      row = await fetchJob(currentJob.id);
    } catch (e) {
      // Deleted server-side: say so. Any other read failure is transient and
      // must not be turned into an invented status.
      if (String(e).includes("job gone")) await setCurrentJob({ id: currentJob.id, status: "removed", result: "" }, scope);
      return;
    }
    if (row.owner_ref !== scope.ownerRef) return;
    const state = isWorkflowJob(row)
      ? String(row.workflow_state || "") : String(row.status || "");
    const status = MIRROR_FOR_STATE[state];
    if (!status || status === currentJob.status) return;
    // A row that is queued again (a requeue, a resume, the owner pressing try
    // again on the phone) has no result of its own yet, and a blank line under
    // "Picking this up" is indistinguishable from a stall for the half minute
    // before the next alarm fires. Say what the wait is.
    const result = String(row.result || "").trim();
    await setCurrentJob({ id: currentJob.id, status, blocked: false,
                          result: result || (status === "queued" ? QUEUED_SOON : "") }, scope);
  } catch (e) { /* best effort — the mirror must never break a run */ }
}

// -------------------------------------------------------- the supervised read
// "You open it. I read it once, in the front window, while you watch."
//
// The whole loop lives in `supervised_read.js`, which touches no Chrome API at
// all; this is the wiring, and it is the only place that decides what Chrome
// capabilities a read is handed. Three of them are deliberately absent:
//
//   * NO chrome.debugger, ever. `trustedClick`/`typeText` in `agent_loop.js`
//     work by attaching CDP to the tab; without an attach there is physically
//     no path from this code to a click or a keystroke, whatever any model
//     replies. The action whitelist is the rule and this is the wall behind it.
//   * NO `mapPage`. The browser arm's page map indexes every button, link and
//     field so the loop can operate them. A read has no business learning
//     where the buttons are, so it reads visible text and nothing else.
//   * NO focus. The read runs in an unfocused tab
//     (`PRODUCTION-ROADMAP.md:176-185` §9 — nothing steals focus, ever). The
//     "front window" in the promise is the phone's: `SupervisedReadView` is
//     what has to be on screen, and the lease below is what proves it was.
async function claimSupervisedRead(ownerRef, agentId) {
  const scope = ownerScope(ownerRef);
  const filter = encodeURIComponent(supervisedReadFilter(ownerRef));
  let rows;
  try {
    const r = await fetch(
      `${await backendBase()}/api/collections/jobs/records?filter=${filter}&perPage=3&sort=created`,
      { headers: await writeHeaders() });
    if (!r.ok) return null;
    rows = (await r.json()).items || [];
  } catch (_) { return null; }
  for (const job of rows) {
    if (activeJobs.has(job.id)) continue;
    // THE LEASE DECIDES, NOT THE QUEUE. A read queued four minutes ago is a
    // read nobody is watching any more, and the check is the same one the
    // extension will make before every single action — so make it here too
    // rather than opening a tab to discover it. `watching_until` is written
    // only by the view that is on screen, so this is not a staleness heuristic
    // like the 12-hour rule above; it is the supervision itself.
    if (leaseLapsed(job.watching_until)) continue;
    try {
      // The claim is also lease-guarded server-side: the backend answers 403
      // when `watching_until` is missing, unparseable or past. A refusal here
      // is therefore normal — the person put their phone down between the poll
      // and the claim — and it is not worth a word to anybody.
      const fresh = await updateJob(job.id, {
        status: "running", claimed_by: agentId, claimed_at: new Date().toISOString(),
      });
      if (fresh.claimed_by !== agentId || fresh.status !== "running") continue;
      if (!(await scopeIsCurrent(scope))) return null;
      claimedOwnerScopes.set(fresh, ownerScope(fresh.owner_ref, scope.generation));
      return fresh;
    } catch (e) {
      console.warn(`Anticipy: could not claim supervised read ${job.id}: ${String(e).slice(0, 160)}`);
      continue;
    }
  }
  return null;
}

// What a supervised read is allowed to do with Chrome. Deliberately a NARROWER
// set than `sideTripDeps` (in `agent_loop.js`), which may click one link: a
// read may not click at all, so no clicking dep is passed and none exists.
function supervisedReadDeps(job, { apiKey, model, ownerRef, agentId, scope }) {
  // Pages settle before they are read. Same constant idea as the side trip's
  // STEP_SETTLE_MS: a mailbox that has not finished rendering reads as empty.
  const settle = () => new Promise((r) => setTimeout(r, 1200));
  return {
    openTab: async (url) => (await createBackgroundTab(url)).id,
    // THE PAGE THE PERSON IS LOOKING AT — the only surface an extract-only
    // source ever gets. The query deliberately does NOT ask for the active tab
    // by that property name: `check_never_foreground.mjs` counts every
    // focus-granting literal in this file and a read must never add one. The
    // frontmost tab is picked in JS instead, which asks the same question
    // without asserting focus on anything.
    currentTab: async () => {
      const tabs = await chrome.tabs.query({ lastFocusedWindow: true });
      const front = tabs.find((t) => t.active) || tabs[0];
      return front ? front.id : null;
    },
    readPage: async (tabId) => {
      await settle();
      const [hit] = await chrome.scripting.executeScript({
        target: { tabId },
        // Visible text and the address, and nothing else. No element index, no
        // form fields, no hrefs: the read is not allowed to know where the
        // buttons are, so it is never told.
        func: () => ({
          text: String(document.body ? document.body.innerText : "").slice(0, 20000),
          url: String(location.href),
        }),
      });
      return (hit && hit.result) || { text: "", url: "" };
    },
    // Same site only — the module checks that before calling this, and the
    // update carries no focus property, so the tab stays where it was.
    navigate: async (tabId, url) => { await chrome.tabs.update(tabId, { url }); await settle(); },
    scrollPage: async (tabId) => {
      await chrome.scripting.executeScript({
        target: { tabId },
        // A fixed fraction of the viewport. The model asks to scroll; it never
        // says how far, because a number from a model is a number from a page.
        func: () => window.scrollBy(0, Math.round(window.innerHeight * 0.9)),
      });
      await settle();
    },
    closeTab: async (tabId) => { try { await chrome.tabs.remove(tabId); } catch (_) { /* gone */ } },
    // RE-READ FROM THE ROW, EVERY TIME. Not cached, not passed in as a param:
    // cached supervision is not supervision, and a params flag would mean
    // "another process decided I may read your inbox" (`side_trip.js`, "WHO SAYS
    // THE AGENT MAY OPEN SOMEBODY'S MAIL").
    // A row that has been deleted throws, and the module reads a throw as
    // "nobody is watching" — fail closed.
    leaseUntil: async () => {
      if (!(await scopeIsCurrent(scope))) return "";
      const row = await fetchJob(job.id);
      return await scopeIsCurrent(scope) && row.owner_ref === scope.ownerRef ? row.watching_until : "";
    },
    askModel: async (system, user) => {
      if (!(await scopeIsCurrent(scope))) throw new Error("browser pairing changed");
      const r = await modelFetch(apiKey, {
        model, temperature: 0, max_tokens: 1024,
        response_format: { type: "json_object" },
        messages: [{ role: "system", content: system }, { role: "user", content: user }],
      });
      if (!r.ok) throw new Error(`read model call failed: ${r.status}`);
      return (await r.json())?.choices?.[0]?.message?.content || "";
    },
    emit: async (event) => {
      if (!(await scopeIsCurrent(scope))) throw new Error("browser pairing changed");
      return pushReadEvent(job, ownerRef, agentId, event);
    },
    // The trace, never the page. `supervised_read.js` is careful to hand this
    // only conclusions and refusals; keep it that way.
    note: (line) => console.log(`Anticipy: ${line}`),
  };
}

// The narration, on its way to the phone.
//
// `goal` carries the job id because that is how `supervisedLines(jobID:)` finds
// these rows, and because the backend now REQUIRES it: guard.pb.js lets an
// agent credential create an event only when the kind is exactly read_line or
// read_fact, `owner_ref` is this agent's owner, and `goal` names a
// supervised_read job of that owner whose lease is still live. Without the id
// the write is refused outright, not merely unfilterable.
//
// WHAT IS NOT HERE IS THE POINT. No page text, no subject line, no message
// body, no URL — `design/LOCAL-FIRST.md:9-11`: only conclusions travel.
// `supervised_read.js` refuses to hand this function anything else, and it
// checks every line, including the ones it wrote itself.
async function pushReadEvent(job, ownerRef, agentId, event) {
  const body = {
    device_id: `chrome-${agentId || "unknown"}`,
    kind: event.kind,
    // 400 IS THE SERVER'S CAP, and it is a privacy bound rather than a column
    // width: guard.pb.js refuses a narration event outside 1–400 characters
    // because the shape of breaking promise 4 ("never the mailbox, never a
    // message, never an attachment") is a read_fact carrying a pasted body,
    // and the page slice this loop works from is ~5,000 characters. In
    // practice nothing is ever cut here — `supervised_read.js` already refuses
    // any line over 140 and any fact over 160 — so this is the belt to that
    // module's braces, and a 403 from it is never retried.
    text: String(event.text || "").slice(0, 400),
    goal: job.id,
    owner_ref: ownerRef,
  };
  // The fence tag, and it must survive the trip: `_UNTRUSTED_SOURCES` in
  // `brain/anticipy_core.py` is keyed on this exact string, and a fact that
  // arrives without it is attacker-controlled text handed to a prompt
  // unfenced. Mail is written by OTHER PEOPLE — anyone can email you.
  if (event.source) body.source = event.source;
  if (event.importance) body.importance = event.importance;
  const r = await fetch(`${await backendBase()}/api/collections/events/records`, {
    method: "POST", headers: await writeHeaders(), body: JSON.stringify(body),
  });
  if (!r.ok) throw new Error(`narration refused (${r.status})`);
}

async function runSupervisedReadJob(job, params, scope) {
  const source = String(params.source || "");
  const { ownerRef, agentId, agentModel } = await chrome.storage.local.get(
    ["ownerRef", "agentId", "agentModel"]);
  // TWO DETERMINISTIC PRECONDITIONS, BOTH REFUSALS RATHER THAN WARNINGS.
  //
  // `consequence` must say read_only. It is the column the rest of the system
  // already uses to mean "this may not act in the world", and a read whose row
  // does not say so is a row somebody built by hand or by mistake.
  if (job.consequence !== "read_only") {
    const result = "That read didn't arrive marked read-only, so I left it alone.";
    await updateJob(job.id, { status: "failed", result });
    await setCurrentJob({ id: job.id, status: "failed", result }, scope);
    return;
  }
  const openrouterKey = await ensureLLMKey(true);
  if (!(await scopeIsCurrent(scope))) return;
  if (!openrouterKey) {
    const result = "I couldn't start: this browser isn't paired to your phone yet.";
    await updateJob(job.id, { status: "failed", result });
    await setCurrentJob({ id: job.id, status: "failed", result }, scope);
    return;
  }
  // A ROW MUST NEVER BE LEFT `running`. The stale sweep above filters on
  // `workflow_id!=""` and a supervised read carries no workflow, so nothing
  // would ever come back for this row — and a read stuck at `running` is a
  // read the person's own app cannot tell from one still in progress. Nothing
  // can ACT on it (the lease has long lapsed, and every claim is lease-guarded
  // server-side), so this is about honesty rather than safety. The write is
  // allowed even with a dead lease because it claims nothing.
  let status = "failed";
  let result = "I couldn't read that one.";
  let trace = `supervised read | source ${source} | engine ${ENGINE_BUILD}`;
  try {
    const out = await runSupervisedRead({
      source,
      // Where the read begins, when the phone named a place. A read of a source
      // whose vocabulary has no `navigate` ignores this entirely and reads the
      // page the person already has open — that check is in the module, where
      // the vocabulary lives.
      startUrl: typeof params.start_url === "string" ? params.start_url : "",
      deps: supervisedReadDeps(job, {
        apiKey: openrouterKey, model: agentModel || undefined, ownerRef, agentId, scope,
      }),
      budget: { steps: READ_MAX_STEPS },
    });
    // A LAPSED LEASE IS A CLEAN ENDING, not a failure: the person backgrounded
    // the app, locked the phone or swiped the view away, and the read stopped
    // itself. Writing `failed` on that would teach them that looking away
    // breaks something, which is the opposite of the lesson. The row still ends
    // terminally — `done` — so nothing is left hanging either way.
    status = out.ok ? "done" : "failed";
    // A lease can now lapse between two facts (the module re-reads it before
    // every judge+emit, audit #77), so what was kept while they watched is
    // counted rather than reported as nothing.
    const kept = `${out.facts.length} thing${out.facts.length === 1 ? "" : "s"} I didn't know about you.`;
    result = out.ok
      ? (out.stopped === "lease"
          ? (out.facts.length ? `You looked away, so I stopped there. Kept ${kept}` : "You looked away, so I stopped there. Nothing kept.")
          : kept)
      : (out.reason || "I couldn't read that one.");
    // The trace is what somebody debugs later: how far the pass got, why it
    // ended, and every action the whitelist refused. Never what was on the
    // page.
    trace = [trace,
             `steps ${out.steps} | ended: ${out.stopped} | lines ${out.lines.length} | facts ${out.facts.length}`,
             ...out.refused.map((line) => `refused: ${line}`)].join("\n");
  } catch (e) {
    // The module catches its own failures and returns them, so arriving here
    // means the WIRING broke — a missing Chrome permission, a page that
    // refused injection. Truncated, because an exception from a page can carry
    // page text.
    trace = `${trace}\nthe wiring failed: ${String(e).slice(0, 200)}`;
    if (String(e).includes("job gone")) throw e;
  }
  // STATUS, RESULT, TRACE — AND NOTHING ELSE. Do not "tidy" this into the
  // release shape used everywhere else in this codebase
  // (`{status, claimed_by: "", claimed_at: null}` — background.js:322/331,
  // brain/worker.py:971). The backend's lease guard treats the mere PRESENCE
  // of a claimed_by key as a claim attempt and 403s it when `watching_until`
  // has lapsed — which is exactly the moment this line runs on the abort path.
  // The row would silently stay `running` while the 403 went unread, which is
  // the whole failure this write exists to prevent. A terminal row's stale
  // claimed_by bothers nobody.
  await updateJob(job.id, { status, result, trace: trace.slice(-8000) });
  await setCurrentJob({ id: job.id, status, result }, scope);
}

async function runJob(job) {
  const scope = claimedOwnerScopes.get(job);
  if (!(await scopeIsCurrent(scope))) return;
  const params = parseJobParams(job);
  // THE THREE-REFUSAL GRACE IS PER RUN, NOT PER BROWSER. livenessRefusals is a
  // module global that only a SUCCESSFUL liveness read clears, so a run whose
  // last probe was a bare 403 left the budget spent: the next errand was then
  // cancelled on its very first probe and the owner was told the browser had
  // been unpaired -- the exact "a blip is not revocation" failure the guard
  // below was written to stop. Each claimed job gets its own three.
  livenessRefusals = 0;
  activeJobs.set(job.id, { job, leaseToken: job.lease_token || "",
                           startedAt: Date.now() });
  await setCurrentJob({ id: job.id, status: "running", doing: jobLine(job, params),
                        result: "", blocked: false }, scope, true);
  try {
    await runJobInner(job, params, scope);
  } catch (e) {
    if (String(e).includes("job gone")) {
      await setCurrentJob({ id: job.id, status: "removed", result: "" }, scope);
      console.warn(`Anticipy: job ${job.id} was deleted — stopping.`);
    } else {
      throw e;
    }
  } finally {
    // LEASE-SCOPED, NOT JOB-SCOPED. When the same worker re-claims a row the
    // sweep handed back (attempt 2), this entry belongs to attempt 2; attempt
    // 1's teardown deleting it by job id left the live attempt with nobody
    // renewing its lease (0 renewals measured) and the popup mirror reading
    // "stopped — another window picked it up" while this window ran it.
    const mine = activeJobs.get(job.id);
    if (!mine || mine.leaseToken === (job.lease_token || "")) {
      activeJobs.delete(job.id);
      jobWriteChains.delete(job.id);
    }
  }
}

// WHAT THE AGENT MAY TREAT AS A VALUE THE OWNER GAVE.
//
// Rendered into the step prompt as FACTS ALREADY GIVEN, which tells the model
// to set form fields to these — so what lands here is not cosmetic. Extracted
// from the run options so the rule can be stated once and tested directly;
// inline, the only way to check it was to read the call site.
//
// Three exclusions, each paid for:
//
//   * UNDERSCORE-PREFIXED KEYS are this system's own bookkeeping (`_workflow`,
//     `_execution_journal`, `_doing`, `_offer_ref`) and were never something a
//     person said. `_offer_ref` is what makes this load-bearing rather than
//     tidy: it is the proof that a consent question was OURS, and the one
//     model that must never be able to reproduce it is precisely the step
//     model this block is rendered for.
//   * owner_answer* — the answer's content already reaches the model inside
//     the approved scope ("They answered: ..."), where it is authority.
//     Handing the same raw sentence over as a "fact" is how it got typed
//     verbatim into OpenTable's Special Requests box (live, 2026-08-15).
//   * the named bookkeeping keys, and `memory`: background knowledge, NOT a
//     given fact. Without that line a short recollection (<200 chars) falls
//     through into FACTS ALREADY GIVEN and the model sets form fields to it.
export function ownerFactsFromParams(params) {
  const p = params && typeof params === "object" ? params : {};
  const NEVER = ["source", "say", "now", "lane", "missing", "authorized",
                 "approved_scope", "needed", "start_url", "task", "assumption",
                 "note", "memory", "resume_tab", "resume_session",
                 // `procedure`: what the server read off the OPEN WEB about how
                 // this kind of task is done. Background, never a given fact —
                 // the same reason `memory` is on this list, and a stronger one,
                 // because its provenance is a web page rather than something he
                 // said. It is an object, so the type filter below would drop it
                 // today; named anyway, because "it happens not to be a string"
                 // is not a rule anybody can rely on.
                 "procedure"];
  const ownerAnswer = (k) => /^owner_answer/i.test(String(k));
  const bookkeeping = (k) => String(k).startsWith("_");
  if (p._workflow?.facts && typeof p._workflow.facts === "object") {
    return Object.fromEntries(Object.entries(p._workflow.facts)
      .filter(([k]) => !ownerAnswer(k) && !bookkeeping(k)));
  }
  return Object.fromEntries(Object.entries(p)
    .filter(([k, v]) => !bookkeeping(k) && !NEVER.includes(k) && !ownerAnswer(k)
      && (typeof v === "string" || typeof v === "number" || typeof v === "boolean")
      && String(v).length < 200));
}

// THE RECEIPT PHOTO, ON ITS WAY OUT OF THE BROWSER.
//
// The bytes exist for a few seconds inside this extension and nowhere else in
// the product (research/2026-08-24-evidence-host.md §5.1-5.3). This is the
// only thing that puts them anywhere durable.
//
// A DATA URL IS DECODED HERE RATHER THAN fetch()ed. `fetch("data:...")` works
// in a service worker, but it makes the deposit depend on the same global that
// every test in this tree replaces with a scripted model — so the one function
// that must keep working while `fetch` is a stub would be the one that cannot
// be tested. atob is not stubbed by anybody.
export function jpegBytes(dataUrl) {
  const s = String(dataUrl || "");
  const comma = s.indexOf(",");
  if (comma < 0 || !s.startsWith("data:image/jpeg;base64,")) return null;
  let bin;
  try { bin = atob(s.slice(comma + 1)); } catch (_) { return null; }
  // The extension's own capture ceiling and the collection's maxSize are the
  // same number on purpose (agent_loop.js:129, 1700000045_evidence.js:72). A
  // frame that got past the first must not die silently at the second.
  if (!bin.length || bin.length > 400000) return null;
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i += 1) bytes[i] = bin.charCodeAt(i);
  return bytes;
}

/// TAKE the frame off the run's result, so that holding it and forgetting to
/// drop it cannot be two separate mistakes.
///
/// This was `delete out.evidenceShot` inline at the call site, and a mutation
/// that removed that line turned ZERO checks red — the bytes leaked into the
/// job row and nothing noticed. A line no test can see is a line that is not
/// really there, so it became a function with a name and a suite. Unconditional
/// on purpose: the shot is removed on every path, not only on success, because
/// a needs_user hand-back is exactly where `out` gets serialized into `params`.
export function takeEvidenceShot(out) {
  if (!out || typeof out !== "object" || !("evidenceShot" in out)) return "";
  const shot = out.evidenceShot;
  delete out.evidenceShot;
  return typeof shot === "string" ? shot : "";
}

/// Deposit one milestone frame and return the receipt entry that points at it,
/// or "" — and "" is a complete answer. A picture that could not be stored is
/// not a reason to fail an errand that already happened: the owner's table is
/// booked either way, and a done-text with no photo is the product's behaviour
/// as of yesterday. The guard's own refusal shape agrees — `owner_ref` is
/// compared against the credential's owner and refused when it disagrees
/// (migration/workers/src/policy/guard.ts), so a wrong claim here fails closed
/// at the door rather than depositing somebody else's page.
export async function depositEvidence(job, shot, deps = {}) {
  const base = deps.backendBase || backendBase;
  const headers = deps.writeHeaders || writeHeaders;
  const send = deps.fetch || ((...a) => fetch(...a));
  const store = deps.storage || chrome.storage.local;
  try {
    const bytes = jpegBytes(shot);
    if (!bytes || !job?.id) return "";
    const { ownerRef } = await store.get(["ownerRef"]);
    // Unowned evidence is a picture nobody can see and nobody can erase
    // (1700000045_evidence.js:55-58). Without an owner there is nothing to
    // deposit, and inventing one is the hole the guard exists to close.
    if (!ownerRef) return "";
    const form = new FormData();
    form.append("owner_ref", ownerRef);
    form.append("job", String(job.id));
    // Bound to the exact effect the receipt names, so a photograph of one
    // action can never end up attached to a different one.
    if (job.effect_key) form.append("effect_key", String(job.effect_key));
    form.append("image", new Blob([bytes], { type: "image/jpeg" }), "receipt.jpg");
    const h = await headers();
    // MULTIPART SETS ITS OWN CONTENT-TYPE, boundary and all. writeHeaders()
    // hardcodes application/json for every other call in this file; leaving it
    // on makes the backend parse the body as JSON and reject a valid upload.
    delete h["Content-Type"];
    const r = await send(`${await base()}/api/collections/evidence/records`,
      { method: "POST", headers: h, body: form });
    if (!r.ok) {
      console.log(`evidence: could not deposit the receipt photo (${r.status}) — the errand still stands`);
      return "";
    }
    const row = await r.json();
    return row && row.id ? `evidence:${row.id}` : "";
  } catch (e) {
    console.log(`evidence: could not deposit the receipt photo (${String(e).slice(0, 120)})`);
    return "";
  }
}

// WHAT A PARKED JOB REMEMBERS ABOUT THE QUESTION IT IS PARKED ON.
//
// `_offer_ref` is the consent offer's ref (side_trip.js `mintOfferRef`), and
// it is written on EVERY needs_user hand-back — the minted value when the run
// handed back one of our own consent offers, and "" when it handed back
// anything else. The empty write is the load-bearing half: a ref that outlived
// its question is a ref the step model can quote back out of the approved
// scope, having read it there, and forge a question with.
//
// The resume stamp is separate and conditional, because a tabless park has no
// tab to point at. Gating the ref on the same condition — which is what the
// shape of this patch invites — would leave stale refs alive on every tabless
// park.
export function handBackParamsPatch(out, parkedSession) {
  const patch = {
    _offer_ref: typeof out?.offerRef === "string" ? out.offerRef : "",
  };
  if (out && out.tabId != null) {
    patch.resume_tab = out.tabId;
    patch.resume_session = parkedSession;
  }
  return patch;
}

// ------------------------------------------- the two writers of a live run
//
// While the loop runs, two callbacks write to its job row: the throttled
// trace writer and the pre-click intent writer. They share ONE view of the
// row and ONE view of `params`, and that sharing is the whole point of this
// factory. Until 2026-09-05 the intent hook called updateJob bare and left
// the trace writer's closure `params` untouched — so the next throttled
// trace write, which serialises that closure, silently ERASED the intent it
// had just written (audit #90, attack finding D). A crash after that write
// left a row with the flag and no intent, which is the exact state the
// intent was added to end.
//
// `job()` / `params()` read the caller's current values; `commit(job,
// params)` writes both back. Every write goes through withJobWrite, whose
// patch is built inside the chain from what the previous write committed.
// `write`, `now` and `session` are injectable so the offline suite can run
// these exact functions against a fake row and a fake clock.
export function rowWriters({ job, params, commit, write = updateJob, now = Date.now,
                             session = browserSessionId }) {
  const adopt = (row) => {
    const active = activeJobs.get(row.id);
    if (active) active.job = row;
  };
  // The step-by-step trace lands on the job row as the agent works, so a run
  // is auditable after the fact. Throttled: at most one write every few
  // seconds, always carrying the latest tail — with ONE exception below.
  const onTrace = (() => {
    let last = 0;
    const first = job();
    const priorTrace = String(first.trace || "").trim();
    const attemptHeader = `=== attempt ${Number(first.attempts) || 1} | engine ${ENGINE_BUILD} ===`;
    return async (history, final = false, checkpoint = {}) => {
      const at = now();
      let current = params();
      // THE `after` HALF OF THE INTENT is written the first time a checkpoint
      // past the click's step arrives, and it does not wait for the throttle:
      // the worker can be reclaimed within those four seconds, and a row
      // whose intent has no `after` sends the recovery model "(none — the
      // page was lost before it was read)". Once written it is never
      // rewritten (effectIntentAfter returns null after that).
      const after = effectIntentAfter(current._effect_intent, checkpoint);
      if (!final && at - last < 4000 && !after) return;
      last = at;
      const currentTrace = history.slice(-160).join("\n");
      const trace = [priorTrace, attemptHeader, currentTrace]
        .filter(Boolean).join("\n").slice(-90000);
      const journal = (Array.isArray(checkpoint?.evidenceJournal)
        ? checkpoint.evidenceJournal : []).slice(-18).map((entry) => ({
          fingerprint: String(entry?.fingerprint || "").slice(0, 200),
          url: String(entry?.url || "").slice(0, 500),
          title: String(entry?.title || "").slice(0, 200),
          text: String(entry?.text || "").slice(0, 2500),
          elements: String(entry?.elements || "").slice(0, 1000),
        }));
      if (journal.length) current = { ...current, _execution_journal: journal };
      // THE ONE LINE HE ACTUALLY SEES.
      //
      // The trace beside it is for whoever debugs this later: it is written
      // for engineers ("step 12: llm error", raw JSON) and the phone has
      // never read it. This is the same moment in his own words, and it rides
      // a write that was already happening every four seconds — so telling
      // him what is going on costs nothing.
      //
      // Without it, a forty-minute run shows the words "On it" and nothing
      // else, and a run working perfectly is indistinguishable from one that
      // died twenty minutes ago.
      const doing = String(checkpoint?.doing || "").slice(0, 120);
      const doingChanged = !!doing && doing !== current._doing;
      if (doingChanged) current = { ...current, _doing: doing };
      if (after) current = { ...current, _effect_intent: { ...current._effect_intent, after } };
      const id = job().id;
      const next = await withJobWrite(id, () => write(id,
        { trace, ...(journal.length || doingChanged || after ? {
          params: JSON.stringify(current),
        } : {}) }, job().lease_token));
      commit(next, current);
      adopt(next);
    };
  })();
  // The loop hands over (decision, state, intent) before every consequential
  // click and Enter. The intent goes to disk beside the flag, stamped with
  // this browser session so a recovery can tell whether the tab id it names
  // is still the same tab — and the closure `params` learns what was written,
  // or the next trace write erases it (see the factory header).
  const onBeforeExternalEffect = async (_decision, _state, intent) => {
    const stamp = await session();
    let written = null;
    const id = job().id;
    const next = await withJobWrite(id, () => {
      const row = job();
      written = markEffectUncertainPatch(row, { ...intent, session: stamp });
      return write(row.id, written, row.lease_token);
    });
    const { _reconciliation: _dropped, ...rest } = params();
    const recorded = written && written.params ? parseJobParams(written)._effect_intent : null;
    commit(next, recorded ? { ...rest, _effect_intent: recorded } : rest);
    adopt(next);
  };
  return { onTrace, onBeforeExternalEffect };
}

// ------------------------------------------ after a crash: did it go through?
//
// Audit #90. For a row whose worker died between a consequential click and
// its receipt: find the SURVIVING tab, read it once, ask one four-state
// question, and hand back `{ verdict, evidence, why }` for recoveryFor to
// write. Never writes, never throws, never navigates, clicks or types.
//
// Which tab: the one the caller names (an in-run path that still holds it),
// else the intent's own tab id — and that only while the intent's browser
// session stamp matches this one, the resumableTabId rule: a tab id is
// unique inside ONE browser session and is handed out again after a restart,
// so an unprovable id is a stranger's tab and is not read.
//
// Which host: reconcile.js checks the tab's URL against the intent's before
// the page is read, and the read page's URL again before anything is sent
// to the model. What the model is sent, and what the row records, are both
// stated in reconcile.js's header.
//
// The read is readPageForRecovery — chrome.scripting only, no debugger, no
// spawner rewrite (its comment in agent_loop.js says what it does not do).
// The model call is reconcileJudge, the #64 shape through the /agent/llm
// proxy; no key, no verdict on a failed call.
export async function recoverUncertainEffect(job, tabId = null, deps = {}) {
  try {
    const raw = parseJobParams(job)._effect_intent;
    const intent = raw && typeof raw === "object" ? raw : null;
    let id = tabId != null && Number.isFinite(Number(tabId)) ? Number(tabId) : null;
    if (id == null && intent && intent.tab != null && Number.isFinite(Number(intent.tab))) {
      const stamp = await (deps.session || browserSessionId)();
      if (stamp && intent.session === stamp) id = Number(intent.tab);
    }
    let tabUrl = "";
    if (id != null) {
      try { tabUrl = String((await chrome.tabs.get(id)).url || ""); }
      catch (_) { tabUrl = ""; }
    }
    const readPage = deps.readPage
      || ((tab) => withTimeout(readPageForRecovery(tab), PAGE_READ_TIMEOUT_MS, "recovery read"));
    const askModel = deps.askModel || (async (system, user) => {
      const apiKey = await ensureLLMKey();
      if (!apiKey) throw new Error("no model key");
      const { agentModel } = await chrome.storage.local.get(["agentModel"]);
      return reconcileJudge(apiKey, agentModel || undefined)(system, user);
    });
    return await reconcileUncertainEffect({
      intent, tabUrl, readPage: () => readPage(id), askModel,
    });
  } catch (e) {
    return { verdict: "no_verdict", why: "nobody could answer",
             evidence: [`why:nobody could answer (${String(e).slice(0, 80)})`] };
  }
}

async function runJobInner(job, params, scope) {
  const generation = scope.generation;
  if (!(await scopeIsCurrent(scope))) return;
  // THE FIRST BRANCH, ABOVE EVERYTHING. A supervised read may never fall
  // through into the executor below: the rewrite three lines down turns any
  // job into `agent_goal`, which is the full click-and-type loop, and running
  // a read through it would put a model with a keyboard inside somebody's
  // mailbox. The lane is claimed by its own poll, so nothing should arrive
  // here by another route — this is the wall that makes "should" irrelevant.
  if (job.lane === "supervised_read") return runSupervisedReadJob(job, params, scope);


  // Canonical plans all use the same adaptive browser executor: a production
  // plan must not bypass verification merely because its goal string happens
  // to match some historical template name.
  if (isWorkflowJob(job) && job.goal !== "agent_goal") {
    const task = params.task || (params.source
      ? `${job.goal} (context: heard "${params.source}")` : job.goal);
    return runJobInner({ ...job, goal: "agent_goal" }, { ...params, task }, scope);
  }

  if (job.goal === "agent_goal") {
    // Autonomous mode: LLM click-loop via chrome.debugger in a background
    // Anticipy tab group (same mechanics as Claude in Chrome / Codex).
    // Model selection is server-controlled and can change during a recovery.
    // Refresh once per job; a failed refresh preserves the last good bundle.
    const openrouterKey = await ensureLLMKey(true);
    if (generation !== identityGeneration) return;
    if (!openrouterKey) {
      const result = "no LLM key: not paired yet, or the backend has none configured";
      const patch = isWorkflowJob(job)
        ? { ...workflowPatch(job, "failed", { reason: result }), result }
        : { status: "failed", result };
      await updateJob(job.id, patch, job.lease_token);
      await setCurrentJob({ id: job.id, status: "failed", result: "I couldn't start: this browser isn't paired to your phone yet." }, scope);
      return;
    }
    try {
      const { agentModel, visionModel, ownerProfile: cachedProfile, agentId: myId } =
        await chrome.storage.local.get(["agentModel", "visionModel", "ownerProfile", "agentId"]);
      // Re-read WHO HE IS at the start of every run. The key bundle is
      // cached for six hours, which is right for a key and wrong for
      // identity: he can add his name and retry in the same minute.
      let ownerProfile = cachedProfile;
      try {
        const pr = await fetch(`${await backendBase()}/agent/key?agent_id=${encodeURIComponent(myId || "")}`,
          { headers: await writeHeaders() });
        if (pr.ok) {
          const fresh = (await pr.json()).owner;
          if (fresh) {
            if (!(await writeIdentity(generation, { ownerProfile: fresh }))) return;
            ownerProfile = fresh;
          }
        }
      } catch (_) { /* keep what we had */ }
      if (generation !== identityGeneration) return;
      // A resumed job goes back to its own parked tab — session, filled form
      // and all — but only while that id still means the tab we parked.
      const resumeTabId = await resumableTabId(params);
      if (!(await scopeIsCurrent(scope))) return;
      // The two row writers share `job` and `params` through these three
      // closures; see rowWriters for why that sharing is load-bearing.
      const writers = rowWriters({
        job: () => job, params: () => params,
        commit: (nextJob, nextParams) => { job = nextJob; params = nextParams; },
      });
      const out = await runAgentGoal(params.task, {
        apiKey: openrouterKey,
        // WHICH QUESTION THIS JOB IS PARKED ON, if it is parked on one of our
        // consent offers. Minted by the run that handed the offer back, stored
        // here, and checked against the question the brain quotes into
        // approved_scope. This is NOT an authorization flag and cannot become
        // one: with a matching ref and no answer, or an answer a model reads as
        // no, both mailbox doors stay shut. What it settles is only "was the
        // question the owner answered OURS" — which used to be settled by
        // testing his quoted question for a sentence AGENT_SYSTEM instructs the
        // step model to write, and a reviewer opened the owner's Gmail through
        // exactly that gap on 2026-08-24.
        //
        // Params is the right home because of who cannot write here: the owner's
        // words land in approved_scope, and the step model emits actions, not
        // params. Neither can put a value in this key.
        offerRef: typeof params._offer_ref === "string" ? params._offer_ref : "",
        startUrl: params.start_url || undefined,
        resumeTabId,
        stillLive: async () => generation === identityGeneration
          && await jobStillLive(job.id, job.lease_token) && generation === identityGeneration,
        ...(agentModel ? { model: agentModel } : {}),
        ...(visionModel ? { visionModel } : {}),
        ownerProfile,
        // The owner already said yes in the app or by text; the gate lives
        // in the job queue, so the browser must not ask a second time.
        // A read-only command is already authorized to perform reversible
        // navigation/search. Its separate readOnly boundary below still
        // mechanically refuses any genuinely consequential control.
        authorized: params.authorized === true || job.consequence === "read_only",
        readOnly: job.consequence === "read_only",
        // Exactly what the owner agreed to, in their own words plus what
        // she told them — the only thing an action is measured against.
        // The model's goal is navigation guidance; the owner's retained words
        // are the authority for exact form values.  A paraphrased goal once
        // turned "battery will not charge" into "battery not charging" and
        // still passed the old combined-scope guard.
        // The owner's later ANSWERS and corrections live only in
        // approved_scope ("You stopped and asked: ... They answered: ...",
        // "They changed: ..."). authority_text alone shadowed them — the
        // browser re-asked questions the owner had already answered (hunt
        // find, 2026-08-15). Verbatim authority stays the base; the Q/A and
        // correction tails ride along.
        scope: (() => {
          const authority = params._workflow?.authority_text || "";
          const approved = String(params.approved_scope || "");
          if (!authority) return approved || params.say || params.source || "";
          const markers = ["You stopped and asked:", "They changed:"];
          const at = markers.map((m) => approved.indexOf(m))
            .filter((i) => i >= 0);
          return at.length
            ? `${authority} ${approved.slice(Math.min(...at))}` : authority;
        })(),
        // Every concrete detail already on the job record (time, party size,
        // an address, an answer he texted) — so the agent SETS them instead
        // of asking for them. Bookkeeping keys are not facts.
        // owner_answer* is excluded from BOTH branches: the answer's content
        // already reaches the model inside the approved scope ("They
        // answered: ..."), where it is authority. Handing the same raw
        // sentence over as a "fact" is how it got typed verbatim into
        // OpenTable's Special Requests box (live, 2026-08-15).
        facts: ownerFactsFromParams(params),
        // WHAT THE BRAIN REMEMBERED, stamped on the row by
        // Anticipy._queue_job. A string, already injection-filtered and length
        // capped brain-side (brain/anticipy_core.py memory_notes) — kept as an
        // opaque string here on purpose: this worker is not the place to decide
        // what is safe to replay, and re-deriving that rule in a second
        // language is how the two copies drift.
        //
        // Read from params, NOT from params._workflow: memory is background,
        // not part of the approved scope, and anything inside _workflow is
        // covered by the digest his approval is bound to.
        memory: backgroundContextFromParams(params),
        // WHAT THE SERVER LOOKED UP BEFORE LETTING GO OF THIS ROW.
        //
        // The research gate parks a world-touching errand on the research lane
        // until the worker has read how the task is done, then hands the row
        // back carrying what it read (brain/worker.py run_preflight_research).
        // Without this the browser waits for that read and then pays to do it
        // again itself.
        //
        // Passed through raw and NOT trusted here: runAgentGoal puts it through
        // learn.js's cleanProcedure — the same door a locally-learned procedure
        // goes through — and reads it back out of the cache before using it.
        // Deciding here what is safe to keep would be the second copy of a rule
        // that already exists, in a second file, and that is how two copies
        // drift. Same doctrine as `memory` directly above.
        //
        // Read from params, NOT from params._workflow: a procedure is
        // background, not part of the approved scope, and anything inside
        // _workflow is covered by the digest his approval is bound to.
        procedure: params.procedure && typeof params.procedure === "object"
          && !Array.isArray(params.procedure) ? params.procedure : null,
        // A Manifest V3 worker may be reclaimed during a long research run.
        // Keep its bounded live-page notebook on the canonical job so a
        // lease retry resumes with evidence already earned instead of
        // forgetting two clinics/listings/vendors and starting from zero.
        initialEvidenceJournal: Array.isArray(params._execution_journal)
          ? params._execution_journal : [],
        // The intent the previous run wrote before its click, if this is a
        // resume after a crash. It seeds the at-most-once gate so the retry
        // refuses to re-send what may already have gone out.
        initialEffectIntent: params._effect_intent && typeof params._effect_intent === "object"
          ? params._effect_intent : null,
        // The step-by-step trace and the pre-click intent, both onto the job
        // row as the agent works — one factory, one shared view of the row.
        onTrace: writers.onTrace,
        onBeforeExternalEffect: isWorkflowJob(job) ? writers.onBeforeExternalEffect : null,
      });
      // A job the owner called off mid-run keeps their decision — writing
      // done/failed over a cancellation resurrects work they stopped.
      if (out.status === "cancelled") {
        // But the loop cannot tell a cancellation from a lost claim: its one
        // liveness test is "still running AND still my lease token", which is
        // equally false when the owner cancels, when the lease expires and the
        // sweep hands the job back, and when a second Chrome profile claims it.
        // A two-minute wifi drop on a train ended an Earls booking with
        // "Stopped: you called this off" — the owner had called nothing off,
        // nothing was written server-side, and that lie was the only record of
        // what happened. Ask the row which of the two it actually was.
        const stoppedByOwner = await ownerCancelled(job.id);
        if (!stoppedByOwner) {
          console.warn(`Anticipy: job ${job.id} lost its claim mid-run — the row went back to the queue, stopping here`);
        }
        await setCurrentJob({ id: job.id,
          status: "stopped",
          result: stoppedByOwner
            ? (out.result || "you called this off — I stopped where I was.")
            : "I lost my hold on this one — my connection dropped or another window picked it up. I stopped where I was and handed it back.",
        }, scope);
        return;
      }
      // needs_user (login wall, CAPTCHA, refused site) is NOT the same state
      // as awaiting_confirm (owner go-ahead pending) — conflating them lets a
      // free-form "yes" re-release a stuck job instead of the intended one.
      const status = out.status === "done" ? "done"
        : out.status === "needs_user" ? "needs_user" : "failed";
      const canonicalState = status === "done" ? "succeeded"
        : status === "needs_user" || job.effect_uncertain ? "needs_user" : "failed";
      // A run that ended failed with an effect outstanding is the in-run
      // twin of the crash the sweep recovers: look at the tab it still holds
      // (if any) and answer the question instead of reciting the sentence.
      const reconciled = status === "failed" && job.effect_uncertain
        ? await recoverUncertainEffect(job, out.tabId ?? null) : null;
      const result = reconciled
        ? reconciledMessage(job, reconciled)
        : (out.result || "");
      // §9: a kept-back tab never surfaces itself — badge + notification, and
      // the owner's click is what focuses it (openHandBack). Surfaced before
      // the job write so a deleted job row can't strand a hidden tab.
      if (canonicalState === "needs_user" && out.tabId != null) {
        await surfaceHandBack(out.tabId, result, "needs_user", scope);
      }
      const parkedSession = canonicalState === "needs_user" && out.tabId != null
        ? await browserSessionId() : "";
      // THE PHOTO GOES FIRST, and then the bytes stop existing.
      //
      // Deposited before the receipt is written, because the receipt has to be
      // able to name the row. Deleted immediately afterwards, because `out` is
      // handed to handBackParamsPatch and read by the trace writer below, and
      // both of those serialize what they are given into a job row — a
      // 100KB data URL in `params` would be a screenshot of a logged-in page
      // sitting in a text column forever, which is the exact thing
      // evidence.pb.js was built to avoid.
      const shot = takeEvidenceShot(out);
      const shotRef = canonicalState === "succeeded"
        ? await depositEvidence(job, shot) : "";
      const transition = isWorkflowJob(job)
        ? workflowPatch(job, canonicalState, {
            reason: result || (canonicalState === "failed"
              ? "browser execution failed" : "the browser needs the owner"),
            effectUncertain: !!job.effect_uncertain,
            // The session stamp travels with the tab id: it is what lets the
            // resume prove the id still points at the tab we parked.
            // WRITTEN ON EVERY needs_user, INCLUDING WITH NO TAB. `_offer_ref`
            // carries the offer this job is now parked on — and an empty string
            // when the hand-back was not one of our offers, which is how a ref
            // is stopped from outliving its question. Gating that clear on
            // `out.tabId != null`, the way the resume stamp is gated, would
            // leave a stale ref alive on any tabless park, and a stale live ref
            // is one the step model can quote back out of the approved scope.
            ...(canonicalState === "needs_user"
              ? { paramsPatch: {
                  ...handBackParamsPatch(out, parkedSession),
                  ...(reconciled ? reconciliationParams(reconciled) : {}),
                } } : {}),
            ...(canonicalState === "succeeded" ? {
              summary: result || "completed",
              verified: out.receipt?.verified === true,
              // PREPENDED, not appended. workflow_state.js:116 keeps the first
              // 12 entries, and the pointer to the photograph is the one entry
              // that nothing else in the product can reconstruct — the rest of
              // the array is a proof index the verifier can rebuild.
              evidence: [...(shotRef ? [shotRef] : []), ...(out.receipt?.evidence || [])],
            } : {}),
          })
        : {
            status, result,
            ...(status === "needs_user"
              ? { params: JSON.stringify({
                  ...params, ...handBackParamsPatch(out, parkedSession) }) } : {}),
          };
      job = await updateJob(job.id, { ...transition, result }, job.lease_token);
      // The job row keeps needs_user (the phone offers Try again on it), but
      // in Chrome the honest word for "you cancelled the debugging bar" is
      // stopped, not "I need you".
      await setCurrentJob({ id: job.id,
        status: out.stoppedInChrome ? "stopped"
          : canonicalState === "needs_user" ? "needs_user" : status,
        result,
      }, scope);
    } catch (e) {
      if (String(e).includes("job gone")) throw e;
      const uncertain = isWorkflowJob(job) && !!job.effect_uncertain;
      // The third of the three sites (see requeueStaleJobs): a run that threw
      // after its click. The loop's teardown has closed the tab by now unless
      // it parked, so this usually reads as "the page it was on is gone" —
      // said as such, rather than as the old constant.
      const patch = uncertain
        ? recoveryFor(job, await recoverUncertainEffect(job))
        : isWorkflowJob(job)
          ? { ...workflowPatch(job, "failed", { reason: String(e), effectUncertain: false }),
              result: String(e) }
          : { status: "failed", result: String(e) };
      const result = patch.result;
      await updateJob(job.id, patch, job.lease_token);
      await setCurrentJob({ id: job.id, status: uncertain ? "needs_user" : "failed", result }, scope);
    }
    return;
  }

  // Nothing reaches this line by any route the system actually uses. A
  // workflow row whose goal is not agent_goal was rewritten to agent_goal at
  // the top of this function, and a row WITHOUT workflow metadata is refused
  // outright at claim. Only a hand-inserted legacy record can arrive here, and
  // the honest thing to do with one is run it as a free-form task through the
  // same verified executor as everything else.
  //
  // This used to consult an ACTIONS table of prefilled Gmail / Calendar /
  // Google-search URLs that parked the job at awaiting_confirm. Dead code with
  // a dangerous shape: it skipped the exact-fact and stop-before-submit checks
  // the agent_goal path applies, and it did so for whichever goal string
  // happened to collide with a template name the brain still emits
  // (brain/llm.py:202 still produces draft_and_send_document).
  const task = params.source ? `${job.goal} (context: heard "${params.source}")` : job.goal;
  return runJobInner({ ...job, goal: "agent_goal" }, { ...params, task }, scope);
}

// Only one poll cycle at a time. There is no push channel: grep extension/ for
// EventSource or WebSocket and you find nothing. The only recurring wake is
// the 0.5-minute chrome.alarms floor — Chrome refuses anything shorter for an
// extension — plus the popup's anticipy-ping and this worker booting. Those
// three still overlap, and overlapping cycles double-claim jobs.
//
// Say the consequence out loud, because a reader who assumes a push channel
// will go looking for one: a job queued a second after a cycle ends waits up
// to ~30s before Chrome starts on it. That is the floor, not a bug to hunt.
//
// The lock is a TIMESTAMP, not a boolean, because a boolean is a permanent
// deafness bug: poll() awaits the whole job run, so a runJob() that never
// settles (a page that never resolves, a debugger command with no reply)
// leaves the flag true forever and every later alarm returns at the guard
// with no log and no recovery. Certification 2026-08-15 caught it exactly:
// case 193 hung in `running` and the next 48 cases were never claimed —
// the same "Chrome says connected but nothing happens" the owner watched
// live. A cycle older than the ceiling is a dead cycle: take the lock.
let pollStartedAt = 0;
// ONE OWNER OF THE NUMBER. agent_loop.js declares the loop's own worst case
// (RUN_WALL_CEILING_MS, ~16.3 min) and has said since it landed that this
// file imports it "rather than keeping a number of its own" — while this file
// kept 12 minutes of its own. Between the two, a run still legitimately inside
// its budget had its lease dropped by the beat at 12:00, its row handed back
// by the sweep at ~14:00, and re-claimed as attempt 2 by the SAME worker while
// attempt 1 was still inside a step (measured 2026-09-12, offline, real
// modules). The executor and the thing that judges the executor cannot
// disagree if only one of them decides.
const POLL_CYCLE_CEILING_MS = RUN_WALL_CEILING_MS;
async function poll() {
  const now = Date.now();
  if (pollStartedAt && now - pollStartedAt < POLL_CYCLE_CEILING_MS) return;
  if (pollStartedAt) {
    console.warn(`Anticipy: previous poll cycle never finished (${Math.round(
      (now - pollStartedAt) / 1000)}s) — reclaiming the queue`);
  }
  pollStartedAt = now;
  try {
    await heartbeat();
    // Housekeeping may NEVER decide whether real work gets claimed. This was
    // awaited bare, so one refused row aborted the cycle before claimJob().
    await requeueStaleJobs().catch((e) => console.warn(
      `Anticipy: stale-job sweep failed (continuing to claim): ${String(e).slice(0, 200)}`));
    // A SUPERVISED READ GOES FIRST, always. Somebody is holding their phone
    // with the view open, watching for a line to appear; a queued errand is
    // not. And the read's own lease is ~30 seconds long, which is shorter than
    // the 0.5-minute alarm floor this worker is stuck with — so a read that
    // waits behind a forty-minute booking is a read that expires unrun and
    // looks, from the phone, exactly like a product that does nothing.
    const { ownerRef: readOwner, agentId: readAgent } =
      await chrome.storage.local.get(["ownerRef", "agentId"]);
    const read = readOwner ? await claimSupervisedRead(readOwner, readAgent) : null;
    if (read) {
      await runJob(read);
      return;
    }
    const job = await claimJob();
    if (job) await runJob(job);
  } catch (e) {
    // Keep polling on the next alarm, but never again silently: this catch
    // swallowed 23 consecutive claim-path 409s in one live run while the
    // heartbeat kept the phone showing "Chrome ready". A dead pipe must be
    // loud in the worker console even when it cannot be fatal.
    console.warn(`Anticipy: poll cycle failed: ${String(e).slice(0, 300)}`);
  } finally {
    // Only the cycle that owns the lock may clear it. A reclaimed-from
    // cycle finishing later must not unlock the one now running.
    if (pollStartedAt === now) pollStartedAt = 0;
  }
}

// Alarms usually survive a browser restart, but Chrome explicitly documents
// that this is not guaranteed. Creating them only in onInstalled left a live
// Chrome process with no queue consumer. This check is deliberately generic:
// it repairs the executor clock, not any particular site or task.
export async function ensureWakeAlarms() {
  for (const name of WAKE_ALARMS) {
    const alarm = await chrome.alarms.get(name);
    if (alarm && Number(alarm.periodInMinutes) === WAKE_PERIOD_MINUTES) continue;
    const timing = {
      delayInMinutes: WAKE_PERIOD_MINUTES,
      periodInMinutes: WAKE_PERIOD_MINUTES,
    };
    // persistAcrossSessions IS CHROME 150+. Older Chrome does not ignore the
    // unknown key — it throws
    //   Error at parameter 'alarmInfo': Unexpected property: 'persistAcrossSessions'
    // so the alarm is never created AT ALL, and every caller of this function
    // swallows the rejection with .catch(() => {}). Measured live in Chrome
    // 148 on 2026-08-19: alarms.getAll() stayed empty forever, a job queued
    // with no extension page open sat untouched for the full 30s window, and
    // the same job was claimed 194ms after the popup was opened. That is
    // exactly "she does nothing until I open the popup" — the whole browser
    // arm reduced to a manual button, in silence, on every Chrome older than
    // 150. Ask for persistence; take a working alarm over a persistent one.
    try {
      await chrome.alarms.create(name, { ...timing, persistAcrossSessions: true });
    } catch (e) {
      console.warn(`Anticipy: this Chrome has no persistent alarms (${String(e).slice(0, 120)}) — using a plain one`);
      await chrome.alarms.create(name, timing);
    }
    // Read it back. A create that quietly did nothing leaves this browser with
    // no clock, and the only symptom is work that never starts.
    if (!(await chrome.alarms.get(name))) {
      console.warn(`Anticipy: Chrome refused the ${name} wake alarm. This browser will only pick up work while an extension page (the popup or the setup page) is open.`);
    }
  }
}

async function stopJob(id, scope) {
  const job = await fetchJob(id);
  if (job.owner_ref !== scope.ownerRef || !(await scopeIsCurrent(scope))) throw new Error("browser pairing changed");
  const active = activeJobs.get(id);
  const fields = isWorkflowJob(job)
    ? { ...workflowPatch(job, "cancelled", { reason: "you stopped this from Chrome" }),
        result: "you stopped this from Chrome" }
    : { status: "cancelled", result: "you stopped this from Chrome" };
  return updateJob(id, fields, active?.leaseToken || job.lease_token || "");
}

async function retryJob(id, scope) {
  const job = await fetchJob(id);
  if (job.owner_ref !== scope.ownerRef || !(await scopeIsCurrent(scope))) throw new Error("browser pairing changed");
  if (!isWorkflowJob(job)) {
    return updateJob(id, { status: "queued", claimed_by: "", claimed_at: null });
  }
  if (job.effect_uncertain) {
    throw new Error("check the site before retrying a possible external effect");
  }
  // AN OWNER'S RETRY IS A NEW GRANT. Attempts survive a requeue, and
  // claimJob cancels anything already at the cap — so pressing "try again"
  // on a job whose three attempts were eaten by worker deaths cancelled it
  // instantly, without running, and reported "I tried this 3 times". The
  // phone-side approval path already resets the budget; this second requeue
  // path did not.
  return updateJob(id, workflowPatch(job, "queued", {
    reason: "the owner asked Chrome to try this approved version again",
    effectUncertain: false,
    attempt: 0,
  }));
}

// The popup's two controls. Both go through updateJob — the same write path
// every other status change uses — so nothing here is a second source of
// truth: a stop lands on the job row, and the running loop's own jobStillLive
// check picks it up within a poll and stops where it is.
chrome.runtime.onMessage.addListener((msg, _sender, respond) => {
  if (!msg || !msg.type) return;
  // Only setup_bridge.js asks this, and that file is injected only after the
  // exact hosted-page check above. Return the disposable display code and the
  // linked bit; the private per-agent credential never enters page JavaScript.
  if (msg.type === "anticipy-setup-state") {
    ensureRegistered()
      .then(async (reg) => {
        if (!reg) throw new Error("browser registration unavailable");
        const s = await chrome.storage.local.get(["pairCode", "paired", "ownerRef"]);
        if (reg.generation !== identityGeneration) throw new Error("browser pairing changed");
        return s;
      })
      .then((s) => respond({
        ok: true,
        code: s.pairCode || "",
        linked: nonemptyIdentity(s.ownerRef),
      }))
      .catch(() => respond({ ok: false, code: "", linked: false }));
    return true;
  }
  // The pairing page's pulse. In a brand-new profile Chrome has been observed
  // to create NO alarms at all (probed live 2026-08-14: getAll() still empty
  // 95s after install), and a worker kept alive by DevTools/automation never
  // re-runs its module top level for a message — so relying on the boot path
  // alone left the battery's worker heartbeating exactly once, pre-pairing,
  // and then deaf forever. The handler does the work itself: every ping
  // re-asserts the alarms and IS a poll, whatever the worker's lifecycle.
  if (msg.type === "anticipy-ping") {
    ensureWakeAlarms().catch(() => {});
    poll();
    respond({ ok: true });
    return;
  }
  // A refused write must never be answered "ok". Both of these swallowed the
  // rejection and reported success, so the popup said "Stopping…" and snapped
  // straight back to "Working on this" — every click, forever, with no error
  // anywhere. Repairing the mirror from the row is what makes the refusal
  // visible: it is almost always stale, and the row is the truth.
  const refused = (what) => async (e) => {
    console.warn(`Anticipy: ${what} refused for ${msg.id}: ${String(e).slice(0, 200)}`);
    await reconcileCurrentJob();
    respond({ ok: false, error: String(e).slice(0, 200) });
  };
  const controlScope = ownerScope(msg.ownerRef);
  if (msg.type === "anticipy-stop" && msg.id) {
    scopeIsCurrent(controlScope).then((current) => {
      if (!current) throw new Error("browser pairing changed");
      return stopJob(msg.id, controlScope);
    })
      .then(async () => {
        await setCurrentJob({ id: msg.id, status: "stopped", result: "You stopped this. Nothing more was done." }, controlScope);
        return scopeIsCurrent(controlScope);
      })
      .then((ok) => respond({ ok: !!ok }))
      .catch(refused("stop"));
    return true;
  }
  if (msg.type === "anticipy-again" && msg.id) {
    scopeIsCurrent(controlScope).then((current) => {
      if (!current) throw new Error("browser pairing changed");
      return retryJob(msg.id, controlScope);
    })
      // Not a blank line: the owner has just pressed a button and the next
      // alarm may be 30 seconds away, so the panel must say that rather than
      // sit there looking like the press did nothing.
      .then(async () => {
        await setCurrentJob({ id: msg.id, status: "queued", result: QUEUED_SOON, blocked: false }, controlScope);
        return scopeIsCurrent(controlScope);
      })
      .then((ok) => respond({ ok: !!ok }))
      .catch(refused("retry"));
    return true;
  }
  // The popup's "Open the page" button: the badge points at the popup, the
  // popup relays the owner's click here — the same owner-gesture path the
  // notification click takes.
  if (msg.type === "anticipy-open-handback" && msg.tabId != null) {
    if (!nonemptyIdentity(msg.ownerRef)) { respond({ ok: false }); return true; }
    openHandBack(msg.tabId, msg.ownerRef).then(ok => respond({ ok: !!ok }))
      .catch(() => respond({ ok: false }));
    return true;
  }
  // A pair code that can never be replaced is a dead end. Drop this install's
  // identity and run the same registration POST first install runs.
  if (msg.type === "anticipy-newcode") {
    recoverRejectedAgentCredential()
      .then((reg) => respond({ ok: !!reg }))
      .catch(() => respond({ ok: false }));
    return true;
  }
});

chrome.runtime.onInstalled.addListener((details) => {
  ensureWakeAlarms().catch(() => {});
  ensureRegistered();
  // If installation began from the hosted guide, keep the person on that one
  // page and turn it into the live pairing surface. Direct installs still get
  // the packaged fallback page, so no route ends in silence.
  if (details.reason === "install") {
    chrome.tabs.query({}).then(async (tabs) => {
      for (const tab of tabs) {
        if (await installHostedSetupBridge(tab.id, tab.url || "")) return;
      }
      // FOCUS-OK(owner-install): installing the extension IS the owner's own
      // action — the pairing page is the one thing allowed to open focused.
      chrome.tabs.create({ url: chrome.runtime.getURL("onboarding.html"), active: true });
    }).catch(() => {
      // FOCUS-OK(owner-install): the query failed, but this is still the
      // owner's install gesture and the packaged pairing page is its fallback.
      chrome.tabs.create({ url: chrome.runtime.getURL("onboarding.html"), active: true });
    });
  }
});

// Existing installs also light up the hosted page. Optional chaining keeps
// older test stubs and Chrome variants from turning a missing event into a
// service-worker load failure; onInstalled above still covers first setup.
chrome.tabs.onUpdated?.addListener?.((tabId, change, tab) => {
  if (change.status === "complete" && tab?.url) {
    installHostedSetupBridge(tabId, tab.url);
  }
});
chrome.runtime.onStartup.addListener(() => {
  // Top-level module evaluation normally does this too. Repeating the check on
  // the explicit browser-start event closes the lifecycle gap without risking
  // duplicate jobs: poll() has its own single-flight guard.
  ensureWakeAlarms().catch(() => {});
  poll();
  refreshBadge();
  reconcileCurrentJob();
});
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === "anticipy-poll") poll();
  // A network blip during a beat is routine, not an error worth logging —
  // the next alarm retries anyway.
  if (a.name === "anticipy-heartbeat") heartbeat().catch(() => {});
});
// Also poll immediately on worker wake, and re-assert the badge — it is
// derived state, and a restarted browser comes up with it blank. The popup's
// job mirror is the same kind of derived state and comes up STALE instead of
// blank, so it gets read back off the row here too.
ensureWakeAlarms().catch(() => {});
poll();
refreshBadge();
reconcileCurrentJob();
